/* Author: jgoudreau */
(function ($) {

    // Here we register the plugin with the ThingWorx jquery plugin framework
    $.registerJqPlugin("sigmaFilter");

    var pluginToExtend = TW.jqPlugins.twFilter.prototype;

    // store copies of the original plugin functions before overwriting
    var functions = {};
    for (var i in pluginToExtend) {
        if (typeof(pluginToExtend[i]) === 'function') {
            functions[i] = pluginToExtend[i];
        }
    }

    TW.jqPlugins.sigmaFilter.prototype = $.extend(true, pluginToExtend, {
        _plugin_afterSetProperties: function () {
            if (this.properties.filterInfo.baseType === 'INTEGER') {
                if (this.properties.filterInfo.fieldName === 'inError') {
                    // Override default behavior for the 'inError' property. This is because the property has multiple
                    // possible states (e.g Enabled, InError, InErrorLast24H, Disabled)
                    this._bindFilterPlugin('sigmaFilter_inError');
                }
                else if (this.properties.filterInfo.fieldName === 'serverStatus') {
                    // Override default behavior for the 'serverStatus' property. This is because the property has multiple
                    // possible states (e.g On, Off, Warning)
                    this._bindFilterPlugin('sigmaFilter_serverStatus');
                }
                else {
                    return functions._plugin_afterSetProperties.apply(this, arguments);
                }
            }
            else {
                return functions._plugin_afterSetProperties.apply(this, arguments);
            }
        },
         _bindFilterPlugin: function (filterName) {
            // call this if you want to reset yourself every time properties are updated.
            this._plugin_beforeDestroy();

            var thisPlugin = this;
            // Use custom filter for this property
            thisPlugin._filterPluginName = filterName;

            $.fn[thisPlugin._filterPluginName].apply(thisPlugin.jqElement, [thisPlugin.properties]);

            thisPlugin.jqElement.bind('filterPropertiesUpdated', function (e, properties) {
                thisPlugin.properties = properties;
            });

            // get the initial values
            thisPlugin.properties = $.fn[thisPlugin._filterPluginName].apply(thisPlugin.jqElement, ['getAllProperties']);
        }
    });

})(jQuery);
//# sourceURL=sigmaFilter.js