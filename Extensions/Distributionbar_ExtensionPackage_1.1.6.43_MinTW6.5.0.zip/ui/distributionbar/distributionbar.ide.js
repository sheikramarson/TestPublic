if (TW.DistributionbarUtilities === undefined)
    TW.DistributionbarUtilities = new Object();

TW.DistributionbarUtilities.createDistributionbar = function (name, description, iconImage) {

    var bar;

    this.widgetProperties = function () {
        return {
            'name': name,
            'description': description,
            'category': ['Common', 'Components'],
            'iconImage': iconImage,
            'isResizable': false,
            'defaultBindingTargetProperty': 'Value',
            'supportsAutoResize': true,
            'properties': {
                'Width': {
                    'description': 'width of widget',
                    'baseType': 'NUMBER',
                    'defaultValue': 150
                },
                //'BarHeight': {
                    //'description': 'height of widget',
                    //'baseType': 'NUMBER',
                    //'defaultValue': 22
                //},
                'Value': {
                    'description': 'Value of the distribution bar',
                    'baseType': 'NUMBER',
                    'defaultValue': 80,
                    'isBindingSource': true,
                    'isBindingTarget': true
                },
                'AvgValue': {
                    'description': 'Average Value of the distribution bar',
                    'baseType': 'NUMBER',
                    'defaultValue': -1,
                    'isBindingSource': true,
                    'isBindingTarget': true
                },
                'Minimum': {
                    'description': 'Minimum acceptable value for the distribution bar.',
                    'baseType': 'NUMBER',
                    'defaultValue': 0,
                    'isBindingSource': true,
                    'isBindingTarget': true
                },
                'Maximum': {
                    'description': 'Maximum acceptable value for the distribution bar.',
                    'baseType': 'NUMBER',
                    'defaultValue': 100,
                    'isBindingSource': true,
                    'isBindingTarget': true
                },
                'TrackingMode': {
                    'description': 'When enabled causes distribution bar to generate events as it changes value. Use with caution!',
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'DistributionbarBGStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultSliderBGStyle'
                },
                'DistributionbarTrackerStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultSliderTrackerStyle'
                },
                'DistributionbarTrackerProgressStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultSliderTrackerProgressStyle'
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
            'ValueChanged': {},
            'AvgValueChanged': {},
        }
    };

    this.afterRender = function() {
        var thisWidget = this;
        var widgetProperties = thisWidget.properties;

        //Validate properties
        var min = widgetProperties['Minimum'];
        if (min === undefined) {
            min = 0;
        }

        var max = widgetProperties['Maximum'];
        if (max === undefined) {
            max = 100;
        }

        var value = widgetProperties['Value'];
        if (value === undefined) {
            value = min;
        }

        var avgValue = widgetProperties['AvgValue'];
        if (avgValue === undefined) {
            avgValue = (max - min ) / 2;
        }


        var DistributionbarTracker = TW.getStyleFromStyleDefinition(thisWidget.getProperty('DistributionbarTrackerStyle'));
        var DistributionbarTrackerBG = TW.getStyleCssGradientFromStyle(DistributionbarTracker);
        var DistributionbarTrackerBorder = TW.getStyleCssBorderFromStyle(DistributionbarTracker);

        var DistributionbarTrackerProgress = TW.getStyleFromStyleDefinition(thisWidget.getProperty('DistributionbarTrackerProgressStyle'));
        var DistributionbarTrackerProgressBG = TW.getStyleCssGradientFromStyle(DistributionbarTrackerProgress);
        var DistributionbarTrackerProgressBorder = TW.getStyleCssBorderFromStyle(DistributionbarTrackerProgress);

        var resource = TW.IDE.getMashupResource();
        var widgetStyles =
            '#' + thisWidget.jqElementId + ' .widget-distributionbar-rightZone { '+ DistributionbarTrackerProgressBG + DistributionbarTrackerProgressBorder +' } ' +
            '#' + thisWidget.jqElementId + ' .widget-distributionbar-controls { '+ DistributionbarTrackerBG + DistributionbarTrackerBorder +' } ';
        resource.styles.append(widgetStyles);
    };

    this.afterSetProperty = function (name, value) {
        var widgetProperties = this.properties;
        var widgetElement = this.jqElement;
        var minVal, maxVal, defaultVal, avgVal;

        var retVal = true;
        switch (name) {
            case 'Width':
            case 'BarHeight':
            case 'EnableTooltip':
            case 'DistributionbarTrackerProgressStyle':
                break;
            case 'Value':
                minVal = this.getProperty('Minimum');
                maxVal = this.getProperty('Maximum');
                defaultVal = this.getProperty('Value');
                this.setProperty('Value', Math.max(Math.min(defaultVal, maxVal), minVal));
                TW.IDE.updateWidgetPropertiesWindow();
                break;
            case 'AvgValue':
                minVal = this.getProperty('Minimum');
                maxVal = this.getProperty('Maximum');
                defaultVal = this.getProperty('Value');
                avgVal = this.getProperty('AvgValue');
                // for the situation that we don't want to display the avg bar, the avg has to be less than 0
                this.setProperty('AvgValue', Math.min(avgVal, maxVal));
                TW.IDE.updateWidgetPropertiesWindow();
                break;
            case 'Minimum':
                this.setProperty('Minimum', Math.min(value, this.getProperty('Maximum')));
                minVal = this.getProperty('Minimum');
                maxVal = this.getProperty('Maximum');
                defaultVal = this.getProperty('Value');
                this.setProperty('Value', Math.max(Math.min(defaultVal, maxVal), minVal));
                TW.IDE.updateWidgetPropertiesWindow();
                break;
            case 'Maximum':
                this.setProperty('Maximum', Math.max(value, this.getProperty('Minimum')));
                minVal = this.getProperty('Minimum');
                maxVal = this.getProperty('Maximum');
                defaultVal = this.getProperty('Value');
                this.setProperty('Value', Math.max(Math.min(defaultVal, maxVal), minVal));
                TW.IDE.updateWidgetPropertiesWindow();
                break;
            case 'DistributionbarBGStyle':
            case 'DistributionbarTrackerStyle':
                break;
            default:
                retVal = false;
                break;
        }
        return retVal;
    };

    this.beforeDestroy = function () {
        bar = null;
    };

    return this;
};

TW.IDE.Widgets.distributionbar = function () {
    this.widgetIconUrl = function() {
        return "../Common/extensions/Distributionbar_ExtensionPackage/ui/distributionbar/images/distributionbar.ide.png";
    };

    var bar = TW.DistributionbarUtilities.createDistributionbar('DistributionBar', 'Horizontal distribution bar.', 'distributionbar.ide.png');

    this.widgetProperties = bar.widgetProperties;
    this.widgetEvents = bar.widgetEvents;

    this.calRatio = function (type) {
        var min = this.getProperty('Minimum') || 0;
        var val = this.getProperty(type);
        if (!type || !val) {
            return min;
        }
        var min = this.getProperty('Minimum') || 0;
        var max = this.getProperty('Maximum') || 100;
        var ratio = 100 / (max - min);

        return (val - min) * ratio;
    }

    // this.renderHtml = function () {

    //     var barStyle = TW.getStyleFromStyleDefinition(this.getProperty('DistributionbarBGStyle'));
    //     var barBG = 'style=" ' + TW.getStyleCssGradientFromStyle(barStyle) + '"';

    //     var html = '';
    //     html += '<div class="widget-content widget-distributionbar">'
    //         + '<div class="widget-distributionbar-panel" '+ barBG +'>'
    //         + '<div class="widget-distributionbar-controls">'
    //         + '<div class="widget-distributionbar-rightZone" style="width:' + this.calRatio('Value') + '%"></div>';

    //     var avgVal = this.getProperty('AvgValue');
    //     if (avgVal >= 0) {
    //         html += '<div class="widget-distributionbar-avg" style="left:' + this.calRatio('AvgValue') + '%"></div>';
    //     }
    //     html += '</div></div>';
    //     return html;
    // };


        this.renderHtml = function () {
            var barStyle = TW.getStyleFromStyleDefinition(this.getProperty('DistributionbarBGStyle'));
            var barBG = 'style=" ' + TW.getStyleCssGradientFromStyle(barStyle) + '"';

            var html = '<style id="widget-distributionbar-styles"></style>';

            html += '<div class="widget-content widget-distributionbar">'
                + '<div class="widget-distributionbar-controls">'
                + '<div class="widget-distributionbar-rightZone" style="width:' + this.calRatio('Value') + '%"></div>';

            var avgVal = this.getProperty('AvgValue');
            if (avgVal >= 0) {
                html += '<div class="widget-distributionbar-avg" style="left:' + this.calRatio('AvgValue') + '%"></div>';
            }else{
                html += '<div class="widget-distributionbar-avg" style="display: none;"></div>'
            }

            html += '</div></div>';

            return html;
        };


    this.afterRender = bar.afterRender;
    this.afterSetProperty = bar.afterSetProperty;


    this.validate = function () {
        var result = [];
        if (!this.isPropertyBoundAsSource('Value') && !this.isPropertyBoundAsTarget('Value')) {
            result.push({ severity: 'warning', message: 'Value for {target-id} is not bound as a source or to any target' });
        }

        return result;
    };
};
