TW.IDE.Dialogs.SmartGridDefinitionEditor = function () {

    this.title = "Smart Grid Definition";
    this.renderDialogHtml = function (widgetObj) {
      var html = '<div class="smartGrid-definition"><p>Here you can enter the JSON that will populate the TableDefinition property of this widget. At runtime, the property value that you set up has precedence over the binding.</p><textarea id="smartGrid-textarea-definition" rows="10" cols="100" style="width:100%"></textarea></div>';
      return html;
    };

    this.afterRender = function (domElementId) {
        this.jqElementId = domElementId;
        this.jqElement = $('#' + domElementId);
    };

    // user is ready to leave the dialog ... validate and save properties in the appropriate property in the property bag
    this.updateProperties = function (widgetObj) {
        // Build the hidden "ColumnFormat" property from the information we have saved locally
        var r = true;
        if(widgetObj.isPropertyBoundAsTarget('TableDefinition')) {
          r = confirm("The TableDefinition property is already binded as target. If you populate it, the binding will not be taken into consideration anymore.");
        }

        if(r && widgetObj.getProperty('TableDefinition')) {
            r = confirm("The TableDefinition property is already populated. Are you sure you want to update it?");
        }

        if (r == true) {
          var thisItem = this;
          var definition = this.jqElement.find("#smartGrid-textarea-definition").val();
          var jsonDefinition = JSON.parse(definition);
          var jsonDefinitionAsString = JSON.stringify(jsonDefinition);
          // set the property
          widgetObj.setProperty('TableDefinition', jsonDefinitionAsString);
        } else {
          this.jqElement.off();
          return false;
        }

        this.jqElement.off();
        return true;
    };
};
