/*
 *
 * Copyright (c) 2015 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 *
 */

/* var s_idePluginVersion = "10.2.30.38"; */

TW.IDE.Widgets.analyticsSmartGridWidget = function () {
    this.widgetIconUrl = function () {
        return "../Common/extensions/AnalyticsSmartGrid_ExtensionPackage/ui/analyticsSmartGrid/analyticsSmartGridIcon.ide.png";
    };

    this.widgetProperties = function () {
        return {
            'name': 'Smart Grid Widget',
            'description': 'Analytics smart grid widget',
            'category': ['Common', 'Data'],
            'defaultBindingTargetProperty': 'Data',
            'isResizable': true,
            'supportsAutoResize': true,
            'customEditor': 'SmartGridDefinitionEditor',
            'customEditorMenuText': 'Smart Grid Definition',
            'properties': {
                'Width': {
                    'defaultValue': 500
                },
                'Height': {
                    'defaultValue': 400
                },
                'TableDefinition': {
                    'isBindingTarget': true,
                    'description': 'The table definition contains the JSON that describes the columns and their types. This property value has precedence over the binding.',
                    'baseType': 'STRING'
                },
                'PreHTML': {
                    'description': 'HTML to render above the table',
                    'baseType': 'STRING'
                },
                'PostHTML': {
                    'description': 'HTML to render below the table',
                    'baseType': 'STRING'
                },
                'MultiSelect': {
                    'description': 'Allow multiple items to be selected?',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'AutoSelectFirstRow': {
                    'description': 'Automatically select the first row of data when new data arrives?',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'Data': {
                    'description': 'Select any infotable as the data source for this property',
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'EditedTable': {
                    'isBindingSource': true,
                    'baseType': 'INFOTABLE'
                }
            }
        };
    };

    this.afterSetProperty = function (name, value) {
      var result = false;
      switch (name) {
            case 'Width':
      			case 'Height':
                result = true;
                break;
            default:
                break;
        }
        return result
    };

    this.renderHtml = function () {
        var html = '<div class="widget-content widget-smartgrid">';
        html += '<img src="../Common/extensions/AnalyticsSmartGrid_ExtensionPackage/ui/analyticsSmartGrid/analyticsSmartGridIcon.ide.png"/>';
        html += '</div>';
        return html;
    };
};
