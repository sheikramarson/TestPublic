TW.IDE.Widgets["converge-datafilter"] = function () {

    this.widgetIconUrl = function () {
        return "../Common/thingworx/widgets/datafilter/datafilter.ide.png";
    };

    this.widgetProperties = function () {
        return {
            'name': 'TWX Utilities Data Filter',
            'description': 'DO NOT USE. Short term widget for TWX Utilities.',
            'category': ['Data'],
            'dataSourceProperty': 'Query',
            'defaultBindingTargetProperty': 'Data',
            'customEditor': 'DataFilterCustomEditor',
            'customEditorMenuText': 'Configure Data Filter Fields',
            'properties': {
                'ColumnFormat': {
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'default': '{}'
                },
                'Width': {
                    'defaultValue': 285
                },
                'Height': {
                    'defaultValue': 26
                },
                'TabSequence': {
                    'description': 'Tab sequence index',
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'Data': {
                    'description': 'Select any infotable as the data source for this property',
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'Query': {
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'baseType': 'QUERY',
                    'isEditable': false,
                    'warnIfNotBoundAsSource': true
                },
                'Z-index': {
                    'isEditable': false,
                    'defaultValue': 9000
                },
				'AddButtonStyle': {
                    'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultDataFilterAddButtonStyle'
                },
				'BarStyle': {
                    'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultDataFilterStyle'
                },
                'FocusStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultButtonFocusStyle'
                },
                'Horizontal': {
                    'baseType':     'BOOLEAN',
                    'defaultValue': false,
                    'description':  'Show the active filters in a horizontal list.'
                }

            }
        };
    };

    this.widgetEvents = function () {
        return {
            'Changed': { 'warnIfNotBound': true }
        }
    };

    this.renderHtml = function () {

		var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('BarStyle'));
		var formatAddBtnResult = TW.getStyleFromStyleDefinition(this.getProperty('AddButtonStyle'));

		var cssInfo = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
		var cssDataFilterBackground = TW.getStyleCssGradientFromStyle(formatResult);
		var cssDataFilterBorder = TW.getStyleCssBorderFromStyle(formatResult);

		var cssDataFilterAddButtonText = TW.getStyleCssTextualNoBackgroundFromStyle(formatAddBtnResult);
		var cssDataFilterAddButtonBackground = TW.getStyleCssGradientFromStyle(formatAddBtnResult);

        var html =
            '<div class="widget-content widget-datafilter" width="100%" height="100%">'
                + '<div class="datafilter-header" style="'+ cssDataFilterBackground + cssDataFilterBorder + '">'
					+ '<div class="datafilter-add" style="'+ cssDataFilterAddButtonBackground +'"><span style="'+ cssDataFilterAddButtonText +'">Add Filter</span></div>'
					+ '<span class="count" style="'+ cssInfo +'">None of X Active Filter(s)</span>'
				+ '</div>'
            + '</div>';
        return html;
    };

    this.afterAddBindingSource = function (bindingInfo) {
        if (bindingInfo['targetProperty'] === 'Data') {

            // get the infoTableDataShape associated with this property
            if (!this.getProperty('ColumnFormat')) {
                var infoTableDataShape = this.getInfotableMetadataForProperty('Data');
                this.setProperty('ColumnFormat', JSON.stringify(infoTableDataShape));
            }
        }
    }

    this.afterSetProperty = function (name, value) {
        var thisWidget = this;
        var result = false;
        switch (name) {
            case 'BarStyle':
			case 'AddButtonStyle':
                result = true;
                break;
            case 'Width':
                if (value < 285) {
                    setTimeout(function () {
                        thisWidget.setProperty('Width', 285);
                        TW.IDE.updateWidgetPropertiesWindow();
                    }, 100);
                }
                result = true;
                break;
        }
        return result;
    };


};
