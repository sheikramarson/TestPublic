TW.IDE.Widgets["twx-utl-debouncer"] = function () {

    this.timerOptions = [
        { value: 100, text: '0.1 sec' },
        { value: 200, text: '0.2 sec' },
        { value: 250, text: '0.25 sec' },
        { value: 300, text: '0.3 sec' },
        { value: 400, text: '0.4 sec' },
        { value: 500, text: '0.5 sec', defaultValue: true },
        { value: 600, text: '0.6 sec' },
        { value: 700, text: '0.7 sec' },
        { value: 750, text: '0.75 sec' },
        { value: 800, text: '0.8 sec' },
        { value: 900, text: '0.9 sec' },
        { value: 1000, text: '1.0 sec' },
        { value: 1250, text: '1.25 sec' },
        { value: 1500, text: '1.5 sec' },
        { value: 1750, text: '1.75 sec' },
        { value: 2000, text: '2.0 sec' }
    ];

    this.widgetProperties = function () {
        return {
            'name': 'TWX Utilities Debouncer',
            'description': 'Buffers the rate at which a function / service can fire when called from multiple inputs.',
            'category': ['Common', 'Components'],
            'isResizable': true,
            'properties': {
                'Width': {
                    'defaultValue': 200
                },
                'Height': {
                    'defaultValue': 28
                },
                'TimerDuration': {
                    'isVisible': true,
                    'baseType': 'NUMBER',
                    'defaultValue': 500,
                    'selectOptions' : this.timerOptions,
                    'description' : 'Delay in seconds before Fired event'
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
            'Fired': {
                'description': 'Event fired when debounce timer is complete.'
            }
        };
    };

    this.widgetServices = function () {
        return {
            'Debounce': {
                'warnIfNotBound': true,
                'description': 'Start debounce timer.'
            },
            'FireImmediately': {
                'description': 'Cancel debounce timer, but trigger Fired event.'
            },
            'Cancel': {
                'description': 'Cancel debounce timer, no Fired event.'
            }
        };
    };

    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-twx-utl-debouncer">';
        html += '<span>Debouncer: Invisible at Runtime</span>';
        html += '</div>';
        return html;
    };
};