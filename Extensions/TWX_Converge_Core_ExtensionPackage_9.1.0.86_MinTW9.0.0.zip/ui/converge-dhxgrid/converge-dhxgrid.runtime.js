(function () {
    var addedDefaultStyles = false;

    TW.Runtime.Widgets["converge-dhxgrid"] = function () {
        var thisWidget = this,
            scrollBarWidth = null, // it holds the calculated scrollbar width
            isAndroid = false, //TW.isAndroidDevice(),
            currentDataInfo,
            currentRows,
            currentSortInfo,
            hasBeenSorted = false,
            nColumns = 0,
            colModel = [], colInfo = [], colFormat,
            updateCount = 0,
            dhxGrid,
            currentFieldsString = '',
            eventIds = [],
            domElementIdOfDhxGrid,
            autoWidthColumns = [],
            gridHeader = '',
            gridInitWidths = '',
            gridColAlign = '',
            gridHeaderColAlign = [],
            gridColTypes = '',
            gridColSorting = '',
            isMultiselect = false,
            selectedRowIndices = [],
            expandGridToShowAllRows = false,
            expandGridToShowAllColumns = false,
            ignoreSelectionChanges = false,
            textSizeClass,
            isPrintLayout = false,
            rowFormat, rowHeight,
            maxScrollPos, showAllColumns, isEditable, isCellTextWrapping;

	    var initGrid = function () {
	        rowFormat = thisWidget.getProperty("RowFormat");
            rowHeight = thisWidget.getProperty('RowHeight') || 30;
            showAllColumns = thisWidget.getProperty('ShowAllColumns', false);
			colFormat = thisWidget.getProperty('ColumnFormat');

	        try {
	            destroyGrid();
                var formatGridHeaderResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridHeaderStyle', 'DefaultGridHeaderStyle'));
                var headerFontWidth = 7;
                if (thisWidget.getProperty('GridHeaderStyle') !== undefined) {
                    textSizeClass = TW.getTextSizeClassName(formatGridHeaderResult.textSize);
                    headerFontWidth = TW.getTextSizeFontWidth(formatGridHeaderResult.textSize);
                }

		dhxGrid = new dhtmlXGridObject(domElementIdOfDhxGrid);
                dhxGrid.fontWidth = headerFontWidth;

	        dhxGrid.enableKeyboardSupport(true);
	        dhxGrid._colModel = colModel;
	        dhxGrid.setImagePath("/Thingworx/Common/dhtmlxgrid/codebase/imgs/");

				// MRD-346: Header doesn't count the width of a column correctly when it contains CKJ characters
				// This will check each header column for the number of these characters they contain
				// Then pad the string with the number of spaces equal to the number of CKJ characters divided by 2
				// Codes are based on codes here: http://www.rikai.com/library/kanjitables/kanji_codes.unicode.shtml
				gridHeader = gridHeader.split(',')
					.map(function(value){
						var count = 0;
						var chars;
						if (chars = value.match(/[\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uffef\u4e00-\u9faf\u3400-\u4dbf]/g)){
							chars.forEach(function(char){
								count++;
							});
							value += Array(Math.ceil(count*.8)).join(' ');
						}
						return value
					})
					.join(',');

	            dhxGrid.setHeader(gridHeader,null,gridHeaderColAlign);
	            dhxGrid.setInitWidths(gridInitWidths);
	            dhxGrid.setColAlign(gridColAlign);
	            if (gridColTypes.length > 0) {
	                dhxGrid.setColTypes(gridColTypes);
	            }
	            dhxGrid.init();
	            dhxGrid.setAwaitedRowHeight(rowHeight);
				dhxGrid.enableAlterCss('even', 'uneven');
		        if( expandGridToShowAllRows ) {
			        if( expandGridToShowAllColumns )  {
				        dhxGrid.enableAutoWidth(true);
			        }
			        dhxGrid.enableAutoHeight(true);
		        }

		        if( expandGridToShowAllRows || isEditable === true)  {
		            dhxGrid.enableSmartRendering(false);
		        } else {
                dhxGrid.enableSmartRendering(true);
                dhxGrid.enablePreRendering();
                dhxGrid.enableMultiline(isCellTextWrapping);
		        }

	            for (var i = 0; i < autoWidthColumns.length; i++) {
	                dhxGrid.adjustColumnSize(autoWidthColumns[i]);
	            }
                // this calls customCellRendering eXcell_twCustom eventually
	            addCustomProcessing(dhxGrid);

	            if (isAndroid) {
	                var nscrolls;
	                var changeIntervalId;

	                var handleScrollLeft = function () {
	                    var gridDomElem = dhxGrid.objBox;
	                    maxScrollPos = 0;
	                    var maxScrollAtATime = gridDomElem.clientWidth * .9;
	                    var scrollAmt = 20;
	                    if ((gridDomElem.scrollLeft - scrollAmt) < 0) {
	                        gridDomElem.scrollLeft = 0;
	                    } else {
	                        gridDomElem.scrollLeft = gridDomElem.scrollLeft - scrollAmt;
	                    }
	                };

	                var handleScrollRight = function () {
	                    var gridDomElem = dhxGrid.objBox;
	                    maxScrollPos = gridDomElem.scrollWidth - gridDomElem.clientWidth + 25;
	                    var scrollAmt = 20;
	                    if ((gridDomElem.scrollLeft + scrollAmt) > maxScrollPos) {
	                        gridDomElem.scrollLeft = maxScrollPos;
	                    } else {
	                        gridDomElem.scrollLeft = gridDomElem.scrollLeft + scrollAmt;
	                    }
	                };

	                var handleScrollUp = function () {
	                    var gridDomElem = dhxGrid.objBox;
	                    maxScrollPos = 0;
	                    var scrollAmt = 20;
	                    if ((gridDomElem.scrollTop - scrollAmt) < 0) {
	                        gridDomElem.scrollTop = 0;
	                    } else {
	                        gridDomElem.scrollTop = gridDomElem.scrollTop - scrollAmt;
	                    }
	                };

	                var handleScrollDown = function () {
	                    var gridDomElem = dhxGrid.objBox;
	                    maxScrollPos = gridDomElem.scrollHeight - gridDomElem.clientHeight + 25;
	                    var scrollAmt = 20;
	                    if ((gridDomElem.scrollTop + scrollAmt) > maxScrollPos) {
	                        gridDomElem.scrollTop = maxScrollPos;
	                    } else {
	                        gridDomElem.scrollTop = gridDomElem.scrollTop + scrollAmt;
	                    }
	                };

	                thisWidget.jqElement.find('.grid-horz-left-all').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    dhxGrid.objBox.scrollLeft = 0;
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    e.stopPropagation();
	                    e.preventDefault();
	                });

	                thisWidget.jqElement.find('.grid-vert-up-all').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    dhxGrid.objBox.scrollTop = 0;
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    e.stopPropagation();
	                    e.preventDefault();
	                });

	                thisWidget.jqElement.find('.grid-vert-down-all').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    var gridDomElem = dhxGrid.objBox;
	                    maxScrollPos = gridDomElem.scrollHeight - gridDomElem.clientHeight + 25;
	                    gridDomElem.scrollTop = maxScrollPos;
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    e.stopPropagation();
	                    e.preventDefault();

	                });

	                thisWidget.jqElement.find('.grid-horz-right-all').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    var gridDomElem = dhxGrid.objBox;
	                    maxScrollPos = gridDomElem.scrollWidth - gridDomElem.clientWidth + 25;
	                    gridDomElem.scrollLeft = maxScrollPos;
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    e.stopPropagation();
	                    e.preventDefault();

	                });

	                thisWidget.jqElement.find('.grid-horz-left').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    nscrolls = 0;
	                    changeIntervalId = window.setInterval(handleScrollLeft, 100);
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    window.clearInterval(changeIntervalId);
	                    e.stopPropagation();
	                    e.preventDefault();
	                });

	                thisWidget.jqElement.find('.grid-horz-right').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    nscrolls = 0;
	                    changeIntervalId = window.setInterval(handleScrollRight, 100);
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    window.clearInterval(changeIntervalId);
	                    e.stopPropagation();
	                    e.preventDefault();
	                });

	                thisWidgetJqElem.find('.grid-vert-up').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    nscrolls = 0;
	                    changeIntervalId = window.setInterval(handleScrollUp, 100);
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    window.clearInterval(changeIntervalId);
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).click(handleScrollRight);

	                thisWidgetJqElem.find('.grid-vert-down').bind('touchstart.dhxgridTouchEvents', function (e) {
	                    $(e.target).addClass('active');
	                    nscrolls = 0;
	                    changeIntervalId = window.setInterval(handleScrollDown, 100);
	                    e.stopPropagation();
	                    e.preventDefault();
	                }).bind('touchend.dhxgridTouchEvents', function (e) {
	                    $(e.target).removeClass('active');
	                    window.clearInterval(changeIntervalId);
	                    e.stopPropagation();
	                    e.preventDefault();
	                });
	            }

                thisWidget.jqElement.find('table.hdr td').addClass(textSizeClass);
	            dhxGrid.setSizes();
	            updateCount = 0;
	        } catch (err) {
	            TW.log.error('Error initializing grid: "' + err + '"');
	        }
	    };

	    var addCustomProcessing = function (dhxGrid) {

	        eventIds.push(dhxGrid.attachEvent("onRowAdded", function (rid) {
	            TW.log.info('row added, rid: ' + rid.toString());
	        }));

	        eventIds.push(dhxGrid.attachEvent("onRowCreated", function (rid, r) {
	            // the 6 is for padding and border
	            $(r).css({
	                'height': (rowHeight).toString() + 'px',
	                'overflow': 'hidden'
	            });
	        }));

	        eventIds.push(dhxGrid.attachEvent("onRowDblClicked", function (rId, cInd) {
	            thisWidget.jqElement.triggerHandler('DoubleClicked');
	        }));

	        // same code in dhxlist and dhxgrid ... update both in sync
	        eventIds.push(dhxGrid.attachEvent("onKeyPress", function (code, cFlag, sFlag) {
	            //TW.log.info('onKeyPress, code: "' + code.toString() + '", cFlag:"' + cFlag.toString() + '", sFlag:"' + sFlag.toString() + '"');
	            switch (code) {
	                case 9: // tab
	                    return false;
	                    break;

	                case 36: //home
	                case 35: //end
	                    var pagingInfo = dhxGrid.getStateOfView();
	                    var curTopRow = pagingInfo[0];
	                    var nRowsTotal = pagingInfo[2];
	                    var rowToShow = curTopRow;

	                    if (code === 36) {
	                        rowToShow = 0;
	                    } else {
	                        rowToShow = nRowsTotal - 1;
	                    }
	                    if (rowToShow < 0) {
	                        rowToShow = 0;
	                    }
	                    if (rowToShow > (nRowsTotal - 1)) {
	                        rowToShow = (nRowsTotal - 1);
	                    }

	                    dhxGrid.showRow(dhxGrid.getRowId(rowToShow));

	                    return false;
	                    break;

	                case 33: //page up
	                case 34: //page down
	                    var pagingInfo = dhxGrid.getStateOfView();
	                    var curTopRow = pagingInfo[0];
	                    var nRowsPerPage = pagingInfo[1]-1;
	                    var nRowsTotal = pagingInfo[2];
	                    var rowToShow = curTopRow;
	                    if (rowToShow < 0) {
	                        rowToShow = 0;
	                    }
	                    if (rowToShow > (nRowsTotal - 1)) {
	                        rowToShow = (nRowsTotal - 1);
	                    }

	                    //TW.log.info('   curTopRow: ' + curTopRow.toString() + ', nRowsPerPage: ' + nRowsPerPage.toString() + ', nRowsTotal: ' + nRowsTotal.toString() + ', rowToShow: ' + rowToShow.toString());
	                    if (code === 33) {
	                        // page up
	                        rowToShow -= nRowsPerPage;
	                    } else {
	                        // page down
	                        rowToShow += nRowsPerPage * 2; // this is because the grid just barely scrolls the row into visibility ... it doesn't show that row
	                    }
	                    if (rowToShow < 0) {
	                        rowToShow = 0;
	                    }
	                    if (rowToShow > (nRowsTotal - 1)) {
	                        rowToShow = (nRowsTotal - 1);
	                    }
	                    dhxGrid.showRow(dhxGrid.getRowId(rowToShow));

	                    return false;
	                    break;

	            }

	            return true;
	        }));

	        eventIds.push(dhxGrid.attachEvent('onSelectStateChanged', function (id, ind) {
	            if (!ignoreSelectionChanges) {
	                selectedRowIndices = [];
	                // select the rows that are selected ... if id is null, ignore this
	                if (id !== null && id !== undefined) {
	                    var selectedRowIds = id.split(',');
	                    for (var i = 0; i < selectedRowIds.length; i++) {
		                    var rowIndex = dhxGrid.getRowIndex(selectedRowIds[i]);

		                    // look up the original row number in case we sorted this table
		                    var row = currentRows[rowIndex];
		                    var actualRowIndex = row._originalRowNumber;
	                        selectedRowIndices.push(actualRowIndex);
	                    }
	                }
	                // in case someone is working off of selected data
	                thisWidget.updateSelection('Data', selectedRowIndices);
	            }
	        }));

	        eventIds.push(dhxGrid.attachEvent('onHeaderClick', onHeaderClickHandler));

            eventIds.push(dhxGrid.attachEvent("onScroll", function (sleft,stop) {
                clearTimeout($.data(this, 'scrollTimer'));
                thisWidget.setProperty('CurrentScrollTop',dhxGrid.getScrollTop());
                dhxGrid.enableMultiline(true);
                $.data(this, 'scrollTimer', setTimeout(function() {
                    dhxGrid.enableMultiline(isCellTextWrapping);
                }, 250));
            }));

	        // special function for parsing the data from Thingworx back-end
	        dhxGrid._process_custom_tw = function (data) {
	            this._parsing = true;
	            var rows = data;                  // get all row elements from data
	            for (var i = 0; i < rows.length; i++) {
	                var id = this.getUID();                                // XML doesn't have native ids, so custom ones will be generated
	                this.rowsBuffer[i] = {                                   // store references to each row element
	                    idd: id,
	                    data: rows[i],
	                    _parser: this._process_custom_tw_row   // cell parser method
	                    //_locator: this._get_custom_tw_data        // data locator method
	                };
	                this.rowsAr[id] = rows[i];                             // store id reference
	            }
	            this.render_dataset();                                   // force update of grid's view after data loading
	            this._parsing = false;
	        };

	        // special function for parsing each row of the data from Thingworx back-end
	        dhxGrid._process_custom_tw_row = function (r, data, ind) {
	            var colModel = this._colModel,
	            strAr = [], i, j, value;

	            var rowStyle = thisWidget.getProperty('GridBackgroundStyle');
	            var rowFormat = thisWidget.getProperty('RowFormat');
	            var defaultRowFormat;
	            if(rowFormat){
		            var formatResult = TW.getStyleFromStateFormatting({DataRow: data, StateFormatting: rowFormat})
		            if(formatResult.styleDefinitionName) {
	                    rowStyle = formatResult.styleDefinitionName;
	                    var tableStyle = TW.getStyleCssTextualFromStyle(formatResult);
	                    var tableStyleBG = TW.getStyleCssGradientFromStyle(formatResult);
	                    var textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
	                    defaultRowFormat = tableStyle + tableStyleBG + textSizeClass;
	                    $(r).attr("style", defaultRowFormat);
		            }
	            }

	            for (i = 0; i < colModel.length; i++) {
	                value = data[colModel[i].name];
	                if ((typeof value === "string") && !value.trim()) {
	                    value = " ";
	                }
	                strAr.push({ RowIndex: ind, Value: value, RowData: data, ColumnInfo: colModel[i], RowHeight: rowHeight, RowFormat : rowFormat, RowStyle : rowStyle, DefaultFormat: defaultRowFormat });
	            }
	            // set just a plain array as no custom attributes are needed
	            r._attrs = {};

	            for (j = 0; j < r.childNodes.length; j++){
                    r.childNodes[j]._attrs = {};
                }

	            // finish data loading this calls customCellRendering
	            this._fillRow(r, strAr);

	            return r;

	        };

	    };

	    var destroyGrid = function () {
	        var i, nEventIds;
	        if (dhxGrid !== undefined && dhxGrid !== null) {
	            try {
	                nEventIds = eventIds.length;
	                for (i = 0; i < nEventIds; i += 1) {
	                    dhxGrid.detachEvent(eventIds[i]);
	                }
	                if (isAndroid) { thisWidget.jqElement.find('*').unbind('.dhxgridTouchEvents'); }
	                dhxGrid.destructor();
	            }
	            catch (gridErr) {
	                TW.log.error('Error destroying grid ' + thisWidget.jqElementId);
	            }
	            dhxGrid = null;
	        }
	    };

	    var toFieldsString = function (infoTableDataShape) {
	        var fldStr = '',
	            flds = 0;
	        for (var x in infoTableDataShape) {
	            flds += 1;
	            if (flds > 1) { fldStr += ','; }
	            fldStr += x;
	        }
	        return fldStr;
	    };

	    var selectGridRows = function (selectedRowIndices, sortChanged) {

		    // pretty easy and fast if the grid has not been sorted
		    if( !hasBeenSorted ) {
			    var nSelectedRows = selectedRowIndices ? selectedRowIndices.length : 0;
			    for (var i = 0; i < nSelectedRows; i += 1) {

				    var rowToSelect = selectedRowIndices[i];

				    dhxGrid.selectRow(rowToSelect,      // row index
					    false,                      // call onSelectChanged [seems to ignore this]
						    i === 0 ? false : true,     // preserve previously selected rows ... set to false on first call, true thereafter
						    i === 0 ? true : false, // scroll row into view ... true on first call, false thereafter
						    		sortChanged);  // was this for a header sort? .. if true we don't want to fire row changed event
			    }
		    } else {
			    // not so fast if we've been sorted ... the indices that come in
			    var nDataRows = currentRows.length;
			    for( var i=0; i<nDataRows; i++) {
				    var row = currentRows[i];
				    if(_.includes(selectedRowIndices,row._originalRowNumber))  {
					    // this row is selected

					    var isFirstSelection = false;
					    if( selectedRowIndices[0] === row._originalRowNumber) {
						    isFirstSelection = true;
					    }

					    dhxGrid.selectRow(i,      // row index
						    false,                      // call onSelectChanged [seems to ignore this]
							    isFirstSelection ? false : true,     // preserve previously selected rows ... set to false on first call, true thereafter
							    isFirstSelection ? true : false,     // scroll row into view ... true on first call, false thereafter
							    sortChanged);  		// was this for a header sort? .. if true we don't want to fire row changed event
				    }
			    }
		    }
	    };

	    var loadGrid = function (sortInd, updateSelection) {
	        var direction = 'asc',
	            nRows = currentRows.length,
	            row;
	        var sortChanged;
	        if (sortInd !== undefined) {
	            sortChanged = true;
		        hasBeenSorted = true;
	            if (currentSortInfo !== undefined) {
	                if (currentSortInfo.ind === sortInd) {
	                    direction = (currentSortInfo.direction === 'asc' ? 'des' : 'asc');
	                    currentSortInfo = { ind: sortInd, direction: direction };
	                    currentRows.reverse();
	                } else {
	                    currentSortInfo = { ind: sortInd, direction: direction };
	                    currentRows.sort(TW.createSorter(colInfo[currentSortInfo.ind]['name'], colInfo[currentSortInfo.ind]['baseType']));
	                }
	            } else {
	                currentSortInfo = { ind: sortInd, direction: direction };
	                currentRows.sort(TW.createSorter(colInfo[currentSortInfo.ind]['name'], colInfo[currentSortInfo.ind]['baseType']));
	            }
	        } else {
	            if (currentSortInfo !== undefined) {
	                if (currentSortInfo.direction === 'asc') {
	                    currentRows.sort(TW.createSorter(colInfo[currentSortInfo.ind]['name'], colInfo[currentSortInfo.ind]['baseType']));
	                } else {
	                    currentRows.sort(TW.createSorter(colInfo[currentSortInfo.ind]['name'], colInfo[currentSortInfo.ind]['baseType']));
	                    currentRows.reverse();
	                }
	            }
	        }

	        dhxGrid.clearAll();
	        dhxGrid.parse(currentRows, "custom_tw");
	        if (currentSortInfo !== undefined) {
	            dhxGrid.setSortImgState(true, currentSortInfo.ind, currentSortInfo.direction);
	        }

	        selectGridRows(selectedRowIndices, sortChanged);

	        if (updateSelection && !sortChanged) {
	            thisWidget.updateSelection('Data', selectedRowIndices);
	        }
	    };

	    var onHeaderClickHandler = function (ind) {
	        loadGrid(ind, true, true /*updateSelection*/);
	        return false;
	    };

	    this.getUpdateCount = function () {
	        return updateCount;
	    };

	    this.runtimeProperties = function () {
	        return {
	            'needsDataLoadingAndError': true,
		        'supportsAutoResize': true,
	            'borderWidth': 0
	        };
	    };

	    this.renderHtml = function () {
			isEditable = thisWidget.getProperty("IsEditable", false);
			isCellTextWrapping = thisWidget.getProperty("CellTextWrapping", false);
	        var html = '';

		    if( $('#runtime-workspace').hasClass('print') && (this.properties.ResponsiveLayout === true)) {
			    this.setProperty('IsPrintLayout',true);
		    }

		    if( this.getProperty('IsPrintLayout') === true ) {
			    isPrintLayout = true;

			    html = '<table cellpadding="0" cellspacing="0" class="widget-content widget-dhxgrid ' + (isCellTextWrapping ? 'textwrap' : '') + '">' +
				    '</table>';
			    return html;
		    }

	        html =
	            '<div class="widget-content widget-dhxgrid data-nodata">'
					+ '<div class="dhxgrid-wrapper">'
		                + '<div class="dhtmlxgrid-container" width="100%" height="100%" tabindex="' + thisWidget.getProperty('TabSequence') + '">'
						+ '</div>'
	                + '</div>'
	            + '</div>';
	        if (isAndroid) {
	            html =
	            '<div class="widget-content widget-dhxgrid data-nodata">'
	                + '<div class="dhtmlxgrid-container-container">'
	                    + '<div class="dhtmlxgrid-container" width="100%" height="100%">'
	                    + '</div>'
	                + '</div>'
	                + '<table class="android-scrollbar" cellspacing="0" cellpadding="0">'
	                    + '<tr>'
	                        + '<td height="100%" width="15%"><span class="horz-btn grid-horz-left-all" ><span class="icon"></span></span></td>'
	                        + '<td height="100%" width="35%"><span class="horz-btn grid-horz-left" ><span class="icon"></span></span></td>'
	                        + '<td height="100%" width="35%"><span class="horz-btn grid-horz-right" ><span class="icon"></span></span></td>'
	                        + '<td height="100%" width="15%"><span class="horz-btn grid-horz-right-all"><span class="icon"></span></span></td>'
	                        + '<td><span class="grid-horz-right" width="25px"></span></td>'
	                    + '</tr>'
	                + '</table>'
	                + '<table class="android-scrollbar-vert" cellspacing="0" cellpadding="0">'
	                    + '<tr>'
	                        + '<td height="15%" valign="middle"><span class="vert-btn grid-vert-up-all"><span class="icon"></span></span></td>'
	                    + '</tr>'
	                    + '<tr>'
	                        + '<td height="35%"><span class="vert-btn grid-vert-up"><span class="icon"></span></span></td>'
	                    + '</tr>'
	                    + '<tr>'
	                        + '<td height="35%"><span class="vert-btn grid-vert-down"><span class="icon"></span></span></td>'
	                    + '</tr>'
	                    + '<tr>'
	                        + '<td height="15%"><span class="vert-btn grid-vert-down-all"><span class="icon"></span></span></td>'
	                    + '</tr>'

	                + '</table>'
	            + '</div>';

	        }
	        return html;
	    };

		this.buildHeaderRowHtml = function(infoTableDataShape) {
			var html = '';
			html +=
				'<thead>';

		    if( showAllColumns === true ) {
                for (var fieldName in infoTableDataShape) {
					html += '<th><div class="print-header-cell">' + Encoder.htmlEncode(fieldName) + '</div></th>'
                }
		    } else {
		        colFormat = thisWidget.getProperty('ColumnFormat');
		        if (colFormat !== undefined && colModel.length === 0) {
		            // translate our internal 'ColumnFormat' to the dhtmlxgrid's idea of a column model
		            for (var i = 0; i < colFormat.formatInfo.length; i++) {
		                var col = colFormat.formatInfo[i];
		                var thisWidth = 100;
		                if (col.Width === 'auto') {
		                    thisWidth = undefined;
		                } else {
		                    thisWidth = col.Width;
		                }
		                colModel.push({ name: col.FieldName, label: TW.Runtime.convertLocalizableString(col.Title), width: thisWidth, align: col.Align, formatoptions: col.FormatOptions, col: col });
		            }
		        }


				_.each(colModel,function(col) {
					html += '<th><div class="print-header-cell">' + Encoder.htmlEncode(col.label) + '</div></th>'
				});

		    }

			html +=
				'</thead>';

			return html;
		}

    // http://stackoverflow.com/questions/21064101/understanding-offsetwidth-clientwidth-scrollwidth-and-height-respectively
    // scrollbarWidth = offsetWidth - clientWidth - getComputedStyle().borderLeftWidth - getComputedStyle().borderRightWidth
    // I'm getting the approximately value here because of the complexity of the grid components we are using, should accurate enough
    this.getScrollBarWidth = function(){
        if(!scrollBarWidth){
          var inner = document.createElement('p');
          inner.style.width = "100%";
          inner.style.height = "200px";

          var outer = document.createElement('div');
          outer.style.position = "absolute";
          outer.style.top = "0px";
          outer.style.left = "0px";
          outer.style.visibility = "hidden";
          outer.style.width = "200px";
          outer.style.height = "150px";
          outer.style.overflow = "hidden";
          outer.appendChild(inner);

          document.body.appendChild(outer);
          var w1 = inner.offsetWidth;
          outer.style.overflow = 'scroll';
          var w2 = inner.offsetWidth;
          if (w1 == w2) w2 = outer.clientWidth;

          document.body.removeChild(outer);

          scrollBarWidth = w1 - w2;
        }
        return scrollBarWidth;
    };

    this.constructColumnFormats = function(colFormat) {
        gridHeader = '';
        gridInitWidths = '';
        gridColAlign = '';
        gridHeaderColAlign = [];
        gridColTypes = '';
        gridColSorting = '';
        nColumns = 0;
        autoWidthColumns = [];
        colModel = [];
        colInfo = [];
        if (colFormat && colFormat.formatInfo) {
            for (var i = 0; i < colFormat.formatInfo.length; i++) {
                var col = colFormat.formatInfo[i];
                var thisWidth = 100;
                if (col.Width === 'auto') {
                    autoWidthColumns.push(i);
                    thisWidth = '100';
                } else {
                    thisWidth = col.Width;
                }

                var allowEdit = false;
                var validationExpression = "";
                var validationMessage = "";
                var editStyle = undefined;

                if(isEditable === true) {
                    allowEdit = col.AllowEdit;
                    validationExpression = col.ValidationExpression;
                    validationMessage = col.ValidationMessage;
                    editStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridEditableFieldStyle', 'DefaultGridEditableFieldStyle'));;
                }

                colModel.push({ name: col.FieldName, label: TW.Runtime.convertLocalizableString(col.Title), width: thisWidth, align: col.Align, sortable: false, allowEdit : allowEdit, validationExpression : validationExpression,  validationMessage : validationMessage, editStyle : editStyle, formatoptions: col.FormatOptions });

                if (i > 0) {
                    gridHeader += ',';
                    gridInitWidths += ',';
                    gridColAlign += ',';
                    gridColTypes += ',';
                    gridColSorting += ',';
                }
                gridHeader +=  TW.Runtime.convertLocalizableString(Encoder.htmlEncode(col.Title)).replace(/,/g,'&#44;');
                gridInitWidths += thisWidth.toString();
                gridColAlign += col.Align || 'left';
                if(thisWidget.getProperty('AlignHeader')){
                    gridHeaderColAlign.push('text-align:'+(col.Align || 'left')+';');
                }
                gridColTypes += 'twcustom';
                gridColSorting += 'str';
                nColumns++;
            }
        } else {
            gridHeader = TW.Runtime.convertLocalizableString("[[mustBeBoundToData]]");
            gridInitWidths = "*";
            gridColAlign = "left";
            gridColTypes = "ro";
            gridColSorting = "str";
        }
    };

	    this.afterRender = function () {

		    if( isPrintLayout ) {
			    return;
		    }

	        //gridHeader = '';
	        //gridInitWidths = '';
	        //gridColAlign = '';
	        //gridHeaderColAlign = [];
	        //gridColTypes = '';
	        //gridColSorting = '';
	        //nColumns = 0;
		    expandGridToShowAllRows = false;
		    expandGridToShowAllColumns = false;
		    if( thisWidget.getProperty('ExpandGridToShowAllRows')  === true ) {
			    expandGridToShowAllRows = true;
			    if( thisWidget.getProperty('ExpandGridToShowAllColumns')  === true ) {
				    expandGridToShowAllColumns = true;
			    }
		    }
	        domElementIdOfDhxGrid = thisWidget.jqElementId + '-dhxgrid';
	        thisWidget.jqElement.find('.dhtmlxgrid-container').attr('id', domElementIdOfDhxGrid);

		    thisWidget.jqElement.on('change','input.grid-cell-STRING,input.grid-cell-NUMBER,input.grid-cell-BOOLEAN,input.grid-cell-DATETIME,input.grid-cell-LOCATION',function(e) {
			    try {
				    var inputEl = $(e.target);
				    var cell = inputEl.closest('.widget-dhxgrid-cell-editable');
				    var rowIndex = parseInt(cell.attr('row-index'));
				    var field = cell.attr('field-name');

				    if( inputEl.hasClass('grid-cell-NUMBER')) {
					    var colFormat = cell.attr('col-format');
				    	try {

				    		var newNumber = parseFloat(inputEl.val());

				    		if(isNaN(newNumber))
				    			throw 'Cannot parse number ' + inputEl.val();

						    currentRows[rowIndex][field] = newNumber;
				    	}
				    	catch(err) {
						    TW.log.error(err);
				    	}

					    var validationExpression = cell.attr('validation-expr');

					    if(validationExpression !== undefined && validationExpression != '' && validationExpression != 'undefined') {
							var activeEditStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridEditableFieldStyle', 'DefaultGridEditableFieldStyle'));
							var activeInvalidStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridInvalidFieldStyle', 'DefaultGridInvalidFieldStyle'));

							var validationMessage = cell.attr('validation-msg');

							if(validationMessage === undefined || validationMessage == '') {
								validationMessage = "Invalid Input";
							}

					    	var validationResult = undefined;

					    	with(currentRows[rowIndex]) { validationResult = eval(validationExpression); };

					    	if(validationResult == true) {
					            var styleDefinition = activeEditStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle + ";text-align:right;")
					            }

					    		cell.attr('title','Valid');
					    	}
					    	else {
					            var styleDefinition = activeInvalidStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle + ";text-align:right;")
					            }

					    		cell.attr('title',validationMessage);

		                        TW.Runtime.showStatusText('error', TW.Runtime.convertLocalizableString(validationMessage));
					    	}
					    }

					    inputEl.val(currentRows[rowIndex][field].format(colFormat));
				    }
				    else if( inputEl.hasClass('grid-cell-DATETIME')) {
					    var colFormat = cell.attr('col-format');

				    	try {
				    		var newDate = TW.DateUtilities.parseDate(inputEl.val(), 'yyyy-MM-dd HH:mm:ss');
				    		if (newDate == null)
				    			throw 'Cannot parse date ' + inputEl.val() + ' using format ' + colFormat;

						    currentRows[rowIndex][field] = newDate;
				    	}
				    	catch(err) {
						    TW.log.error(err);
				    	}

					    var validationExpression = cell.attr('validation-expr');

					    if(validationExpression !== undefined && validationExpression != '' && validationExpression != 'undefined') {
							var activeEditStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridEditableFieldStyle', 'DefaultGridEditableFieldStyle'));
							var activeInvalidStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridInvalidFieldStyle', 'DefaultGridInvalidFieldStyle'));

							var validationMessage = cell.attr('validation-msg');

							if(validationMessage === undefined || validationMessage == '') {
								validationMessage = "Invalid Input";
							}

					    	var validationResult = undefined;

					    	with(currentRows[rowIndex]) { validationResult = eval(validationExpression); };

					    	if(validationResult == true) {
					            var styleDefinition = activeEditStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle)
					            }

					    		cell.attr('title','Valid');
					    	}
					    	else {
					            var styleDefinition = activeInvalidStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle)
					            }

					    		cell.attr('title',validationMessage);

					    		TW.Runtime.showStatusText('error', TW.Runtime.convertLocalizableString(validationMessage));
					    	}
					    }

                        inputEl.val(TW.DateUtilities.formatDate(currentRows[rowIndex][field], colFormat));
				    }
				    else if( inputEl.hasClass('grid-cell-BOOLEAN')) {
					    var colFormat = cell.attr('col-format');

					    currentRows[rowIndex][field] = inputEl.is(':checked');

					    var validationExpression = cell.attr('validation-expr');

					    if(validationExpression !== undefined && validationExpression != '' && validationExpression != 'undefined') {
							var activeEditStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridEditableFieldStyle', 'DefaultGridEditableFieldStyle'));
							var activeInvalidStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridInvalidFieldStyle', 'DefaultGridInvalidFieldStyle'));

							var validationMessage = cell.attr('validation-msg');

							if(validationMessage === undefined || validationMessage == '') {
								validationMessage = "Invalid Input";
							}

					    	var validationResult = undefined;

					    	with(currentRows[rowIndex]) { validationResult = eval(validationExpression); };

					    	if(validationResult == true) {
					            var styleDefinition = activeEditStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle)
					            }

					    		cell.attr('title','Valid');
					    	}
					    	else {
					            var styleDefinition = activeInvalidStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle)
					            }

					    		cell.attr('title',validationMessage);

					    		TW.Runtime.showStatusText('error', TW.Runtime.convertLocalizableString(validationMessage));
					    	}
					    }

                    } else if (inputEl.hasClass('grid-cell-LOCATION')) {
                        var colFormat = cell.attr('col-format');
                        try {
                            var validLoc = false;
                            var locationValues = inputEl.val().split(":");
                            if (locationValues && locationValues.length == 2) {
                                var latVal = locationValues[0];
                                var longVal = locationValues[1];
                                var locationEntry = {};
                                if (!isNaN(latVal) && !isNaN(longVal)) {
                                    validLoc = true;
                                    locationEntry.latitude = parseFloat(latVal);
                                    locationEntry.longitude = parseFloat(longVal);
                                    if (currentRows[rowIndex][field]) {
                                        locationEntry.elevation = currentRows[rowIndex][field].elevation;
                                    }
                                }
                            }

                            if (!validLoc) {
                                throw 'Cannot parse location ' + inputEl.val();
                            }
                            currentRows[rowIndex][field] = locationEntry;
                        }
                        catch (err) {
                            TW.log.error(err);
                        }

					    var validationExpression = cell.attr('validation-expr');

					    if(validationExpression !== undefined && validationExpression != '' && validationExpression != 'undefined') {
							var activeEditStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridEditableFieldStyle', 'DefaultGridEditableFieldStyle'));
							var activeInvalidStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridInvalidFieldStyle', 'DefaultGridInvalidFieldStyle'));

							var validationMessage = cell.attr('validation-msg');

							if(validationMessage === undefined || validationMessage == '') {
								validationMessage = "Invalid Input";
							}

					    	var validationResult = undefined;

					    	with(currentRows[rowIndex]) { validationResult = eval(validationExpression); };

					    	if(validationResult == true) {
					            var styleDefinition = activeEditStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle + ";text-align:right;")
					            }

					    		cell.attr('title','Valid');
					    	}
					    	else {
					            var styleDefinition = activeInvalidStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle + ";text-align:right;")
					            }

					    		cell.attr('title',validationMessage);

		                        TW.Runtime.showStatusText('error', TW.Runtime.convertLocalizableString(validationMessage));
					    	}
					    }

					    inputEl.val(currentRows[rowIndex][field].latitude + " : " + currentRows[rowIndex][field].longitude);
				    }
				    else {
					    currentRows[rowIndex][field] = inputEl.val();

					    var validationExpression = cell.attr('validation-expr');

					    if(validationExpression !== undefined && validationExpression != '' && validationExpression != 'undefined') {
							var activeEditStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridEditableFieldStyle', 'DefaultGridEditableFieldStyle'));
							var activeInvalidStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridInvalidFieldStyle', 'DefaultGridInvalidFieldStyle'));

							var validationMessage = cell.attr('validation-msg');

							if(validationMessage === undefined || validationMessage == '') {
								validationMessage = "Invalid Input";
							}

					    	var validationResult = undefined;

					    	with(currentRows[rowIndex]) { validationResult = eval(validationExpression); };

					    	if(validationResult == true) {
					            var styleDefinition = activeEditStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle)
					            }

					    		cell.attr('title','Valid');
					    	}
					    	else {
					            var styleDefinition = activeInvalidStyle;

					            if (styleDefinition !== undefined && styleDefinition.styleDefinitionName !== undefined) {
					                var tableStyle = TW.getStyleCssTextualFromStyle(styleDefinition);
					                inputEl.attr('style',tableStyle)
					            }

					    		cell.attr('title',validationMessage);

		                        TW.Runtime.showStatusText('error', TW.Runtime.convertLocalizableString(validationMessage));
					    	}
					    }


				    }
				    // update the hidden element and then adjust the column size
					if($(this).parent().children('div:hidden').text($(this).val()).length > 0){
						// find the row, find the index of this column, then adjust only this column.
						var columnIndex = $(this).closest('tr').children('td').index($(this).closest('td'));
						if(autoWidthColumns.indexOf(columnIndex) > -1){
							dhxGrid.adjustColumnSize(columnIndex);
						}
					}

				    thisWidget.setProperty('EditedTable',thisWidget.getProperty('EditedTable'));

			    } catch( err ) {
				    TW.log.error('Error updating cell');
			    }
		    });


			var formatRowBackgroundResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RowBackgroundStyle', 'DefaultRowBackgroundStyle'));
			var formatRowAlternateBackgroundResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RowAlternateBackgroundStyle', 'DefaultRowAlternateBackgroundStyle'));
			var formatRowHoverResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RowHoverStyle', 'DefaultRowHoverStyle'));
			var formatRowSelectedResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RowSelectedStyle', 'DefaultRowSelectedStyle'));
			var formatGridFocusResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('FocusStyle', 'DefaultFocusStyle'));
			var formatGridHeaderResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridHeaderStyle', 'DefaultGridHeaderStyle'));
			var formatGridBackgroundResult = TW.getStyleFromStyleDefinition(this.getProperty('GridBackgroundStyle', 'DefaultGridBackgroundStyle'));

			var cssRowBackground = TW.getStyleCssGradientFromStyle(formatRowBackgroundResult);
			var cssRowBackgroundText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowBackgroundResult);
			var cssRowAlternateBackground = TW.getStyleCssGradientFromStyle(formatRowAlternateBackgroundResult);
			var cssRowAlternateBackgroundText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowAlternateBackgroundResult);
			var cssRowHover = TW.getStyleCssGradientFromStyle(formatRowHoverResult, true);
			var cssRowHoverText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowHoverResult, true);
			var cssRowSelected = TW.getStyleCssGradientFromStyle(formatRowSelectedResult, true);
			var cssRowSelectedText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowSelectedResult, true);
			var cssGridHeaderBackground = TW.getStyleCssGradientFromStyle(formatGridHeaderResult);
			var cssGridHeaderText = TW.getStyleCssTextualNoBackgroundFromStyle(formatGridHeaderResult);
			var cssGridFocus = TW.getStyleCssBorderFromStyle(formatGridFocusResult);
			var cssGridBackground = TW.getStyleCssGradientFromStyle(formatGridBackgroundResult);
			var cssGridBorder = TW.getStyleCssBorderFromStyle(formatGridBackgroundResult);
			var cssGridHeaderBorder = TW.getStyleCssBorderFromStyle(formatGridHeaderResult);

            if (this.getProperty('GridHeaderStyle') !== undefined) {
                textSizeClass = TW.getTextSizeClassName(formatGridHeaderResult.textSize);
            }

			if (thisWidget.getProperty('RowBackgroundStyle', 'DefaultRowBackgroundStyle') === 'DefaultRowBackgroundStyle'
	                && thisWidget.getProperty('RowAlternateBackgroundStyle', 'DefaultRowAlternateBackgroundStyle') === 'DefaultRowAlternateBackgroundStyle'
	                && thisWidget.getProperty('RowHoverStyle', 'DefaultRowHoverStyle') === 'DefaultRowHoverStyle'
	                && thisWidget.getProperty('GridHeaderStyle', 'DefaultGridHeaderStyle') === 'DefaultGridHeaderStyle'
	                && thisWidget.getProperty('GridBackgroundStyle', 'DefaultGridBackgroundStyle') === 'DefaultGridBackgroundStyle'
	                && thisWidget.getProperty('RowSelectedStyle', 'DefaultRowSelectedStyle') === 'DefaultRowSelectedStyle'
	                && thisWidget.getProperty('FocusStyle', 'DefaultFocusStyle') === 'DefaultFocusStyle') {
	                if (!addedDefaultStyles) {
	                    addedDefaultStyles = true;
	                    var defaultStyles = '.widget-dhxgrid .gridbox {'+ cssGridBackground + '}' +
	                    					' .widget-dhxgrid .dhxgrid-wrapper {'+ cssGridBorder +'}' +
	                    					' .widget-dhxgrid .dhxgrid-wrapper.focus {'+ cssGridFocus +'}' +
											'.widget-dhxgrid .xhdr .twdhtmlxcell { border: none; }' +
											' div.gridbox .xhdr {'+ cssGridHeaderBackground +'}' +
											'.widget-dhxgrid .gridbox table.obj tr {'+ cssRowBackground + '}' +
	                 						'.widget-dhxgrid .gridbox table.obj td {'+ cssRowBackgroundText +'}' +
	                 						'.widget-dhxgrid .gridbox table.obj tr.uneven {'+ cssRowBackground + cssRowBackgroundText +'}' +
	                 						'.widget-dhxgrid .gridbox table.obj tr.even {'+ cssRowAlternateBackground + cssRowAlternateBackgroundText +'}' +
	                 						'.widget-dhxgrid .gridbox table.obj tr:hover td {'+ cssRowHover + cssRowHoverText +'}' +
	                 						'.widget-dhxgrid .gridbox table.obj tr:hover td div {'+ cssRowHover + cssRowHoverText +'}' +
	                 						'.widget-dhxgrid .gridbox table.obj tr.rowselected td {'+ cssRowSelected + cssRowSelectedText +'}' +
	                 						'.widget-dhxgrid .gridbox table.obj tr.rowselected td div {'+ cssRowSelected + cssRowSelectedText +'}' +
	                 						'.widget-dhxgrid .gridbox table.hdr td { '+ cssGridHeaderBackground + '}' +
											'.widget-dhxgrid .gridbox table.hdr td > div { '+ cssGridHeaderText +'text-transform:'+thisWidget.getProperty("GridHeaderTextCase")+'; text-shadow: none; }';

	                    $.rule(defaultStyles).appendTo(TW.Runtime.globalWidgetStyleEl);
	                }
	        } else {

				var styleBlock =
					'<style>' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox {'+ cssGridBackground + '}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .xhdr tr th:last-child, .xhdr tr td:last-child { padding-right:' + this.getScrollBarWidth() + 'px !important; }' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .xhdr td { '+ cssGridBorder +' border-left:none; border-top:none; border-bottom: none;}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .dhxgrid-wrapper {'+ cssGridBorder +'}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .dhxgrid-wrapper.focus {'+ cssGridFocus +'}' +
						'#' + thisWidget.jqElementId + ' div.gridbox .xhdr {'+ cssGridHeaderBackground + cssGridHeaderBorder + ' width: auto !important;}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.obj tr.uneven {'+ cssRowBackground + cssRowBackgroundText +'}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.obj tr.even {'+ cssRowAlternateBackground + cssRowAlternateBackgroundText +'}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.obj tr:hover td {'+ cssRowHover + cssRowHoverText +'}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.obj tr:hover td div {'+ cssRowHover + cssRowHoverText +'}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.obj tr.rowselected td {'+ cssRowSelected + cssRowSelectedText +'}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.obj tr.rowselected td div {'+ cssRowSelected + cssRowSelectedText +'}' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.hdr td { '+ cssGridHeaderBackground + ' }' +
						'#' + thisWidget.jqElementId + '.widget-dhxgrid .gridbox table.hdr td > div { '+ cssGridHeaderText +'text-transform:'+thisWidget.getProperty("GridHeaderTextCase")+'; text-shadow:none; }' +
					'</style>';

				$(styleBlock).prependTo(thisWidget.jqElement);
	        }

	        if (isAndroid) {
	            // adjust the grid to be 25 px less in width and height for the table to fit
	            thisWidget.jqElement.find('.dhtmlxgrid-container-container').width(thisWidget.getProperty('Width') - 25).height(thisWidget.getProperty('Height') - 25);
	        }

            isMultiselect = thisWidget.getProperty('MultiSelect', false);
	        colFormat = thisWidget.getProperty('ColumnFormat');

			var activeEditStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridEditableFieldStyle', 'DefaultGridEditableFieldStyle'));

	        this.constructColumnFormats(colFormat);

            thisWidget.jqElement.find('.dhtmlxgrid-container').on('focus', function (e) {
               thisWidget.jqElement.find('.dhxgrid-wrapper').addClass('focus');
            });

            thisWidget.jqElement.find('.dhtmlxgrid-container').on('blur', function (e) {
                thisWidget.jqElement.find('.dhxgrid-wrapper').removeClass('focus');
            });

            initGrid();
            dhxGrid.enableTooltips(colModel);

	    };

	    // called every time that the infotable is updated
	    this.updateProperty = function (updatePropertyInfo, localUpdate) {
	        var reInitGrid = false;
	        var infoTableDataShape;

	        if (updatePropertyInfo.TargetProperty === "ScrollTop") {
	        	dhxGrid.setScrollTop(updatePropertyInfo.RawSinglePropertyValue);
	        }

            if (updatePropertyInfo.TargetProperty === "ColumnFormat") {
                colFormat = updatePropertyInfo.RawDataFromInvoke;
                this.setProperty(updatePropertyInfo.TargetProperty, colFormat);
                this.constructColumnFormats(colFormat);
                initGrid();
                if (currentDataInfo) { // rebuild
                    this.updateProperty(currentDataInfo, true);
                }
            }

	        if (updatePropertyInfo.TargetProperty === "Data") {
	            updateCount += 1;
	            currentDataInfo = updatePropertyInfo,
	            currentRows = currentDataInfo.ActualDataRows;
		        if( currentRows === undefined ) {
			        currentRows = [];
		        }
	            infoTableDataShape = currentDataInfo.DataShape;
	            selectedRowIndices = updatePropertyInfo.SelectedRowIndices;

			    if( isPrintLayout ) {

				    var html = '';
				    html += this.buildHeaderRowHtml(infoTableDataShape);

				    _.each(currentRows,function(row) {
				        html += '<tr>';
					    var htmlRet = '';
					    if(showAllColumns === true ) {
					        var renderer = TW.Renderer.DEFAULT;
	                        for (var fieldName in infoTableDataShape) {
	                            //var fieldDef = infoTableDataShape[fieldName];
				                htmlRet = renderer['renderHtml']({
				                    DataRow: row,
				                    ValueFieldName: fieldName,
				                    Value: row[fieldName],
				                    ColumnInfo: {}
				                });
						        html += '<td><div class="print-cell">' + htmlRet + '</div></td>';
						    }
					    } else {
							_.each(colModel,function(field) {
								var fmtOptions = field.formatoptions;
						        var renderer = TW.Renderer[fmtOptions.renderer];
						        if (renderer !== undefined) {
						            if (renderer['renderHtml'] !== undefined && (typeof renderer['renderHtml']) === "function") {
						                htmlRet = renderer['renderHtml']({
						                    DataRow: row,
						                    ValueFieldName: field.name,
						                    Value: row[field.name],
						                    FormatString: fmtOptions.FormatString,
						                    StateFormatting: fmtOptions.formatInfo,
						                    ColumnInfo: {}
						                });
						            }
						        } else {
						            TW.log.error('Unrecognized renderer in dhxgrid print: "' + renderer + '"');
                                }

                                html += '<td><div class="print-cell">' + htmlRet + '</div></td>';
                            });
                        }
                        html += '</tr>';

                    });

				    this.jqElement.html(html);

					var formatRowBackgroundResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RowBackgroundStyle', 'DefaultRowBackgroundStyle'));
					var formatRowAlternateBackgroundResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RowAlternateBackgroundStyle', 'DefaultRowAlternateBackgroundStyle'));
					var formatRowSelectedResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('RowSelectedStyle', 'DefaultRowSelectedStyle'));
					var formatGridBackgroundResult = TW.getStyleFromStyleDefinition(this.getProperty('GridBackgroundStyle', 'DefaultGridBackgroundStyle'));
					var formatGridHeaderResult = TW.getStyleFromStyleDefinition(thisWidget.getProperty('GridHeaderStyle', 'DefaultGridHeaderStyle'));

					var cssRowBackground = TW.getStyleCssGradientFromStyle(formatRowBackgroundResult);
					var cssRowBackgroundText = TW.getStyleCssTextualNoBackgroundFromStyle(formatRowBackgroundResult);
					var cssGridHeaderBackground = TW.getStyleCssGradientFromStyle(formatGridHeaderResult);
					var cssGridHeaderText = TW.getStyleCssTextualNoBackgroundFromStyle(formatGridHeaderResult);
					var cssGridBackground = TW.getStyleCssGradientFromStyle(formatGridBackgroundResult);
					var cssGridBorder = TW.getStyleCssBorderFromStyle(formatGridBackgroundResult);
					var textSize = TW.getTextSize(formatGridBackgroundResult.textSize);

					var printstyles =
					'<style>' +
						'#' + thisWidget.jqElementId + ' { '+ cssGridBackground + cssGridBorder +' border-bottom: none; border-right: none; }' +
						'#' + thisWidget.jqElementId + ' thead th { '+ cssGridHeaderText + cssGridBorder + cssGridHeaderBackground +'text-transform:'+thisWidget.getProperty("GridHeaderTextCase")+'; border-left: none; border-top: none; }' +
						'#' + thisWidget.jqElementId + ' .print-header-cell { padding:5px; }' +
						'#' + thisWidget.jqElementId + ' .print-cell { '+ cssRowBackground +' line-height: ' + rowHeight + 'px; min-height: ' + rowHeight + 'px; height:auto !important; height: ' + rowHeight + 'px; } ' +
						'#' + thisWidget.jqElementId + ' td { '+ cssRowBackgroundText + cssGridBorder + textSize +' border-left:none; border-top:none; }' +
					'</style>';

					$(printstyles).prependTo(thisWidget.jqElement);

					return;
			    }

		        // we used to only clone if the table was editable ... we clone it always now in case it has been sorted
	            var clonedTable = TW.InfoTableUtilities.CloneInfoTable({ "dataShape" : { "fieldDefinitions" : infoTableDataShape}, "rows" : currentRows });

	            if(isEditable === true) {
		            thisWidget.setProperty('EditedTable', clonedTable);
	            }

	            currentRows = clonedTable.rows;

	            // record the initial row number in each row - when sorted, it's important to know the original row number
		        var nRows = currentRows.length;
	            for( var i=0; i<nRows; i++) {
		            currentRows[i]._originalRowNumber = i;
	            }

	            colFormat = thisWidget.getProperty('ColumnFormat');

	            if (showAllColumns) {
	                var newFldsString = toFieldsString(currentDataInfo.DataShape);
	                if (currentFieldsString === '' || currentFieldsString !== newFldsString) {
	                    currentFieldsString = newFldsString;
	                    reInitGrid = true;
	                }

	                (function () {
	                    if (reInitGrid) {
	                        if (currentDataInfo.SourceProperty !== '') {
	                            if (currentDataInfo.ActualDataRows !== undefined && currentDataInfo.ActualDataRows[0] !== undefined && currentDataInfo.ActualDataRows[0][currentDataInfo.SourceProperty] !== undefined && currentDataInfo.ActualDataRows[0][currentDataInfo.SourceProperty].rows !== undefined) {
	                                currentRows = currentDataInfo.ActualDataRows[0][currentDataInfo.SourceProperty].rows;
	                                infoTableDataShape = currentDataInfo.ActualDataRows[0][currentDataInfo.SourceProperty].dataShape.fieldDefinitions;
	                            }
	                        }
	                        currentSortInfo = undefined;
	                        gridHeader = '';
	                        gridInitWidths = '';
	                        gridColTypes = '';
	                        gridColSorting = '';
	                        nColumns = 0;
	                        colModel = [];
	                        autoWidthColumns = [];
	                        colInfo = [];

	                        for (var x in infoTableDataShape) {
	                            var fieldDef = infoTableDataShape[x];
	                            if (gridHeader.length > 0) {
	                                gridHeader += ',';
	                                gridInitWidths += ',';
	                                gridColTypes += ',';
	                                gridColSorting += ',';
	                            }
	                            gridHeader += Encoder.htmlEncode(x);

	                            if (gridInitWidths.length === 0) {
	                                gridInitWidths += '100';
	                            } else {
	                                gridInitWidths += '50';
	                            }

	                            colInfo.push({
	                                name: x,
	                                baseType: fieldDef.baseType
	                            });
	                            //colModel.push({ name: col.FieldName, label: TW.Runtime.convertLocalizableString(col.Title), width: thisWidth, align: col.Align, sortable: false, formatoptions: col.FormatOptions });
	                            // if you update this, also update dhxgrid.customdialog.ide.js to update the defaults at IDE time
	                            switch (fieldDef.baseType) {
	                                case "DATETIME":
	                                    colModel.push({ name: x, label: x, sortable: false, formatoptions: { renderer: "DATETIME", FormatString: TW.Runtime.convertLocalizableString(TW.Renderer.DATETIME.defaultFormat) } });
	                                    break;
	                                case "LOCATION":
	                                    colModel.push({ name: x, label: x, sortable: false, formatoptions: { renderer: "LOCATION", FormatString: '0.00' } });
	                                    break;
	                                case "TAGS":
	                                    colModel.push({ name: x, label: x, sortable: false, formatoptions: { renderer: "TAGS", FormatString: 'plain' } });
	                                    break;
	                                case "HYPERLINK":
	                                    colModel.push({ name: x, label: x, sortable: false, formatoptions: { renderer: "HYPERLINK", FormatString: '_blank' } });
	                                    break;
	                                case "IMAGELINK":
	                                    colModel.push({ name: x, label: x, sortable: false, formatoptions: { renderer: "IMAGELINK" } });
	                                    break;
	                                default:
	                                    colModel.push({ name: x, label: x, sortable: false, formatoptions: { renderer: "DEFAULT" } });
	                            }
	                            gridColTypes += 'twcustom';
	                            gridColSorting += 'str';
	                            nColumns++;
	                        }

	                        for (var i = 0; i < nColumns; i++) {
	                            autoWidthColumns.push(i);
	                        }

	                        initGrid();
	                    }
	                }());

	                // don't updateSelection here ... it's handled later in this function
		            ignoreSelectionChanges = true;
	                loadGrid(undefined, false /*updateSelection*/);
		            ignoreSelectionChanges = false;

	                for (var i = 0; i < autoWidthColumns.length; i++) {
	                    dhxGrid.adjustColumnSize(autoWidthColumns[i]);
	                }

	                if (!updatePropertyInfo.IsBoundToSelectedRows ) {
	                    // only do this if it's bound to AllData ...
	                    dhxGrid.enableMultiselect(isMultiselect);
	                }

	            } else {
	                if (colFormat !== undefined) {
	                    if (colInfo.length === 0) {
	                        for (var i = 0; i < colFormat.formatInfo.length; i += 1) {
	                            colInfo.push({
	                                name: colFormat.formatInfo[i].FieldName,
	                                baseType: ((currentDataInfo.DataShape !== undefined && currentDataInfo.DataShape[colFormat.formatInfo[i].FieldName] !== undefined) ? currentDataInfo.DataShape[colFormat.formatInfo[i].FieldName].baseType : undefined)
	                            });
	                        }
	                    }

	                    // don't updateSelection here ... it's handled later in this function
			            ignoreSelectionChanges = true;
	                    loadGrid(undefined, false /*updateSelection*/);
			            ignoreSelectionChanges = false;
	                }

	                for (var i = 0; i < autoWidthColumns.length; i++) {
	                    dhxGrid.adjustColumnSize(autoWidthColumns[i]);
	                }
	            }

				if( thisWidget.properties.ResponsiveLayout === true ) {
					try {
						thisWidget.extendLastColumn(thisWidget.jqElement.width());
					} catch (err) {
					}
				}

		        if( expandGridToShowAllRows ) {
			        dhxGrid.setSizes();
			        var width = dhxGrid.entBox.style.width;
			        var height = dhxGrid.entBox.style.height;
			        if( expandGridToShowAllColumns ) {
				        thisWidget.jqElement.css('width',width);
			        }
			        thisWidget.jqElement.css('height',height);

		        }

	            if (!updatePropertyInfo.IsBoundToSelectedRows) {
	                // only do this if it's bound to AllData ...
	                dhxGrid.enableMultiselect(isMultiselect);

	                if (currentRows.length > 0) {
                        if (selectedRowIndices !== undefined && selectedRowIndices.length === 0 && this.getProperty('AutoSelectFirstRow') === true) {
	                        // do this with delay ... if you have a lot of grids accessing the same data, they may not have populated and we're already telling them the row to select :)
	                        setTimeout(function () {
	                            // select the first row
	                            ignoreSelectionChanges = true;
	                            dhxGrid.selectRow(0, false, false, true);
	                            ignoreSelectionChanges = false;

	                            // tell the runtime that we updated the selection
	                            thisWidget.updateSelection('Data', [0]);
	                        }, 100);
	                    } else {
	                        if (!ignoreSelectionChanges) {
	                            ignoreSelectionChanges = true;
	                            selectGridRows(selectedRowIndices);
	                            ignoreSelectionChanges = false;
	                        }
	                    }
	                    thisWidget.updateSelection('Data', selectedRowIndices);
	                } else {
	                    // mark that none are selected since we just got the data and there are no rows
	                    thisWidget.updateSelection('Data', []);
	                }
	            }
	        } else if (updatePropertyInfo.TargetProperty === "top" || updatePropertyInfo.TargetProperty === "left" || updatePropertyInfo.TargetProperty === "width" || updatePropertyInfo.TargetProperty === "height") {
	            thisWidget.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
	            thisWidget.jqElement.css(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue + "px");
	            // update the inner object's height and width if updated ... don't mess with top / left of inner object
	            if (updatePropertyInfo.TargetProperty === "width" || updatePropertyInfo.TargetProperty === "height") {
	                $('#' + domElementIdOfDhxGrid).css(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
	            }
	        }

			if (isCellTextWrapping === true) {
				thisWidget.jqElement.addClass('CellTextWrapping');
			}

	    };

		this.extendLastColumn = function(width) {
			var widthSoFar = 0;
			for( var i=0; i<(dhxGrid.cellWidthPX.length-1); i++ )  {
				widthSoFar += dhxGrid.cellWidthPX[i];
			}

			var lastColumnWidth = dhxGrid.cellWidthPX[dhxGrid.cellWidthPX.length-1];

			if( (widthSoFar + lastColumnWidth) < width ) {
				dhxGrid.setColWidth(dhxGrid.cellWidthPX.length-1,width-widthSoFar-25 /* in case of scrollbar */ );
			}
		};

		this.resize = function(width,height) {
//            thisWidget.jqElement.css('Width', width + "px");
//            thisWidget.jqElement.css('Height', height + "px");
            // update the inner object's height and width if updated ... don't mess with top / left of inner object
            //$('#' + domElementIdOfDhxGrid).css('Width', width).css('Height',height);
			dhxGrid.setSizes();
			if( this.properties.ResponsiveLayout === true ) {
				for (var i = 0; i < autoWidthColumns.length; i++) {
					dhxGrid.adjustColumnSize(autoWidthColumns[i]);
				}
				this.extendLastColumn(width);
			}
		};

	    // callback from runtime to tell us that the selection has been changed by another widget
	    this.handleSelectionUpdate = function (propertyName, selectedRows, newSelectedRowIndices) {
	        // if we're called with a selection change before we've even been loaded, no point going through the exercise
	        if (dhxGrid !== undefined) {
	            // note that we're in the middle of selection so we don't tell the runtime what it already knows (that the selection has changed)
	            if (!ignoreSelectionChanges) {
	                ignoreSelectionChanges = true;
		            selectedRowIndices = newSelectedRowIndices;
	                if (selectedRowIndices.length === 0) {
	                    dhxGrid.clearSelection();
	                }
	                selectGridRows(selectedRowIndices);
	                ignoreSelectionChanges = false;
		            thisWidget.setProperty('CurrentScrollTop',dhxGrid.getScrollTop());
	            }
	        }
	    };

        // will check or uncheck all rows based on parameter
        this.checkOrUncheckAllRows = function(checkAllRows) {
            var fn = function(evt) {
                evt.stopPropagation();
            };
            thisWidget.jqElement.find('div.dhtmlxgrid-container input:checkbox').on("click", fn).each(
                function(index, element) {
                    if (checkAllRows) {
                        // ensure only clicking rows that are not already checked
                        if (element.checked === false) {
                            element.click();
                        }
                    } else {
                        // ensure only clicking rows that are already checked
                        if (element.checked === true) {
                            element.click();
                        }
                    }
                }).off("click", fn);
        };

        this.serviceInvoked = function (serviceName) {
            var widgetReference = this;
            if (serviceName === 'ClearData') {
                setTimeout(function () {
                    widgetReference.updateProperty({TargetProperty: 'Data'});
                }, 100);
            } else if (serviceName === 'CheckAll') {
                widgetReference.checkOrUncheckAllRows(true);
            } else if (serviceName === 'UncheckAll') {
                widgetReference.checkOrUncheckAllRows(false);
            } else {
                TW.log.error('TWX Utilities Grid, unexpected serviceName invoked "' + serviceName + '"');
            }
        };

	    this.beforeDestroy = function () {
	        destroyGrid();
	        dhxGrid = null;
	        currentDataInfo = null;
	        currentRows = null;
	    };
	};
}());