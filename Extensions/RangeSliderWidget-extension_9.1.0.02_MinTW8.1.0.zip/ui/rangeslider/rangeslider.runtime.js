(function ($) {
    var MIN_SLIDER_INDEX = 0;
    var MAX_SLIDER_INDEX = 1;

    TW.Runtime.Widgets.rangeslider = function () {
        "use strict";
        var widget = this,
            sliderInst,
            sliderUpdateFn = function (event, ui) {

                //current values
                var minvalue = widget.getProperty('minValue');
                var maxvalue = widget.getProperty('maxValue');

                var min = Math.min(maxvalue - 1, ui.values[0]);
                var max = Math.max(minvalue + 1, ui.values[1]);

                widget.jqElement.find('input[data-slider-low="true"]').val(min);
                widget.jqElement.find('input[data-slider-high="true"]').val(max);
            };

        this.renderHtml = function () {
            var elem = ['<div class="widget-content">',
                '<div class="Range-slider__static-value-container Range-slider__static-value-container--left">',
                '<input type="text" id="slider-low" data-slider-low="true" class="Range-slider__value" value="' + this.getProperty("minValue") + '"/>',
                '</div>',
                '<div class="Range-slider__slider-container">',
                '<div id="rangeslider" class="Range-slider__slider"></div>',
                '</div>',
                '<div class="Range-slider__static-value-container Range-slider__static-value-container--right">',
                '<input type="text" id="slider-high" data-slider-high="true" class="Range-slider__value" value="' + this.getProperty("maxValue") + '">',
                '</div>',
                '</div>'].join('');
            return elem;
        };

        this.serviceInvoked = function (serviceName) {

            if (serviceName === 'reset') {

                var min = widget.getProperty('min');
                var max = widget.getProperty('max');
                widget.setProperty('minValue', min);
                widget.setProperty('maxValue', max);
                sliderInst.slider("values", MIN_SLIDER_INDEX, min);
                sliderInst.slider("values", MAX_SLIDER_INDEX, max);
                widget.jqElement.find('input[data-slider-low="true"]').val(min);
                widget.jqElement.find('input[data-slider-high="true"]').val(max);

                this.renderHtml();

                widget.jqElement.triggerHandler('ValueChanged');
            }
        }

        this.afterRender = function () {
            sliderInst = this.jqElement.find('.Range-slider__slider').slider({
                range: 'range', //this.getProperty("range"),
                min: this.getProperty("min"),
                max: this.getProperty("max"),
                values: [this.getProperty("minValue"), this.getProperty("maxValue")],
                animate: this.getProperty("animate"),
                disabled: this.getProperty("disabled"),
                orientation: 'horizontal', // this.getProperty("orientation"),
                step: this.getProperty("step"),
                stop: function (event, ui) {
                    //current values
                    var minvalue = widget.getProperty('minValue');
                    var maxvalue = widget.getProperty('maxValue');

                    var min = Math.min(maxvalue - 1, ui.values[0]);
                    var max = Math.max(minvalue + 1, ui.values[1]);

                    widget.setProperty('minValue', min);
                    widget.setProperty('maxValue', max);

                    sliderInst.slider("values", MIN_SLIDER_INDEX, min);
                    sliderInst.slider("values", MAX_SLIDER_INDEX, max);

                    widget.jqElement.triggerHandler('ValueChanged');
                },
                slide: function (event, ui) {
                    sliderUpdateFn(event, ui);
                }
            });

            function isInteger(num) {
                try {
                    return num == parseInt(+num, 10) && !isNaN(parseInt(num));
                }
                catch (err) {
                    return false;
                }
            }

            widget.jqElement.on('change', 'input[data-slider-low="true"]', function (event) {

                var $el = $(event.currentTarget);
                if (isInteger($el.val())) {

                    try {
                        var val = $el.val();
                        var num = parseInt(val);
                        if (num < widget.getProperty('maxValue') && num >= widget.getProperty('min')) {
                            widget.setProperty('minValue', $el.val());
                            sliderInst.slider("values", MIN_SLIDER_INDEX, $el.val());
                        } else {
                            $el.val(widget.getProperty('min'));
                            widget.setProperty('minValue', $el.val());
                            sliderInst.slider("values", MIN_SLIDER_INDEX, $el.val());
                        }
                    } catch (err) {
                        $el.val(widget.getProperty('min'));
                        widget.setProperty('minValue', $el.val());
                        sliderInst.slider("values", MIN_SLIDER_INDEX, $el.val());
                    }
                }
                else {
                    $el.val(widget.getProperty('min'));
                    widget.setProperty('minValue', $el.val());
                    sliderInst.slider("values", MIN_SLIDER_INDEX, $el.val());
                }
            });

            widget.jqElement.on('change', 'input[data-slider-high="true"]', function (event) {

             var $el = $(event.currentTarget);
                if (isInteger($el.val())) {

                    try {
                        var val = $el.val();
                        var num = parseInt(val);
                        if (num > widget.getProperty('minValue') && num <= widget.getProperty('max')) {
                            widget.setProperty('maxValue', $el.val());
                            sliderInst.slider("values", MAX_SLIDER_INDEX, $el.val());
                        } else {
                            $el.val(widget.getProperty('max'));
                            widget.setProperty('maxValue', $el.val());
                            sliderInst.slider("values", MAX_SLIDER_INDEX, $el.val());
                        }
                    } catch (err) {
                        $el.val(widget.getProperty('max'));
                        widget.setProperty('maxValue', $el.val());
                        sliderInst.slider("values", MAX_SLIDER_INDEX, $el.val());
                    }
                }
                else {
                    $el.val(widget.getProperty('max'));
                    widget.setProperty('maxValue', $el.val());
                    sliderInst.slider("values", MAX_SLIDER_INDEX, $el.val());
                }

            });

            widget.jqElement.on('change', '#slider-low', function (event) {
                var $el = $(event.currentTarget);
                var val = $el.val();
                try {
                    var num = parseInt(val);
                    if (num >= widget.getProperty('min') && num < widget.getProperty('maxValue')) {
                        widget.setProperty('minValue', num);
                        widget.jqElement.triggerHandler('ValueChanged');
                    } else {
                        $el.val(widget.getProperty('minValue'));
                    }
                } catch (err) {
                    $el.val(widget.getProperty('minValue'));
                }
            });

            widget.jqElement.on('change', '#slider-high', function (event) {
                var $el = $(event.currentTarget);
                var val = $el.val();
                try {
                    var num = parseInt(val);
                    if (num <= widget.getProperty('max') && num > widget.getProperty('minValue')) {
                        widget.setProperty('maxValue', num);
                        widget.jqElement.triggerHandler('ValueChanged');
                    } else {
                        $el.val(widget.getProperty('maxValue'));
                    }
                } catch (err) {
                    $el.val(widget.getProperty('maxValue'));
                }
            })

            if (this.getProperty("disabled") == true) {
                $('input[id*="slider-"]').attr("disabled", true);
            }
            ;
        };

        this.updateProperty = function (updatePropertyInfo) {
            var min = this.getProperty('min');
            var max = this.getProperty('max');
            var minValue = this.getProperty('minValue');
            var maxValue = this.getProperty('maxValue');

            var rawValue = updatePropertyInfo.RawSinglePropertyValue;
            var val = this.getProperty(updatePropertyInfo.TargetProperty);

            switch (updatePropertyInfo.TargetProperty) {
                case 'minValue':
                    if (val !== rawValue) {
                        val = rawValue;
                        if (isNaN(val)) {
                            val = min;
                        }
                        if (val > maxValue) {
                            this.setProperty('minValue', maxValue - 1);
                        } else {
                            this.setProperty('minValue', val < min ? min : val);
                        }
						sliderInst.slider("values", MIN_SLIDER_INDEX, val);
						$("#min-value").text(parseInt(val).toLocaleString());
                        $("#slider-low").val(val);
                    }
                    break;
                case 'maxValue':
                    if (val !== rawValue) {
                        val = rawValue;
                        if (isNaN(val)) {
                            val = max;
                        }
                        if (val < minValue) {
                            this.setProperty('maxValue', minValue + 1);
                        } else {
                            this.setProperty('maxValue', val > max ? max : val);
                        }
						sliderInst.slider("values", MAX_SLIDER_INDEX, val);  // TODO: Const
						$("#max-value").text(parseInt(val).toLocaleString());
                        $("#slider-high").val(val);
						
                    }
                    break;
                // TODO: we also should validate the current minValue and maxValue
                case 'min':
                    if (val !== rawValue) {
                        val = rawValue;
                        if (isNaN(val)) {
                            val = min;
                        }

                        // we shouldn't check here, because when min got updated, the max has not update yet
                        // same thing for the max. The deep reason is we never know which binding got always triggered first
                        // or maybe we only bind either min or max.
                        // if(val > max){
                        // val = max - 1; // should be step size
                        // }
                        this.setProperty('min', val);
                        this.setProperty('minValue', val);
                        sliderInst.slider("option", "min", val);
                        sliderInst.slider("values", MIN_SLIDER_INDEX, val);
                        $("#min-value").text(parseInt(val).toLocaleString());
                        $("#slider-low").val(val);
                    }
                    break;
                case 'max':
                    if (val !== rawValue) {
                        val = rawValue;
                        if (isNaN(val)) {
                            val = min;
                        }

                        // if(val < min){
                        // val = min + 1; // should be step size
                        // }
                        this.setProperty('max', val);
                        this.setProperty('maxValue', val);
                        sliderInst.slider("option", "max", val);
                        sliderInst.slider("values", MAX_SLIDER_INDEX, val);  // TODO: Const
                        $("#max-value").text(parseInt(val).toLocaleString());
                        $("#slider-high").val(val);
                    }
                    break;
            }
        };
    };
})(jQuery);
