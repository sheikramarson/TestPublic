﻿/*global Encoder,TW */

TW.IDE.Widgets.triggerButton = function () {
    "use strict";
	this.widgetIconUrl = function() {
        return  "../Common/extensions/TriggerWidget-extension/ui/triggerButton/images/eventsrouter.ide.png";
    }
    var roundedCorners = true;
    this.widgetProperties = function () {
        return {
            'name': 'Trigger Service',
            'description': 'Identifies the index of the triggered service and can trigger additional services',
            'category': ['Common'],
			'supportsAutoResize': true,
            'properties': {
                'TriggerIndex': {
                    'description': 'Index of the service triggered',
                    'baseType': 'INTEGER',
                    'defaultValue': 0,
					'isBindingSource': true
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
            'Triggered': { 'warnIfNotBound': true }
        };
    };

    this.widgetServices = function() {
        return {
            'Trigger1': { 'warnIfNotBound': false },
			'Trigger2': { 'warnIfNotBound': false },
			'Trigger3': { 'warnIfNotBound': false },
			'Trigger4': { 'warnIfNotBound': false },
			'Trigger5': { 'warnIfNotBound': false },
			'Trigger6': { 'warnIfNotBound': false },
			'Trigger7': { 'warnIfNotBound': false },
			'Trigger8': { 'warnIfNotBound': false },
			'Trigger9': { 'warnIfNotBound': false },
			'Trigger10':{ 'warnIfNotBound': false }
        }
    }
    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Label' :
            case 'Style':
            case 'Width':
            case 'Height':
            case 'RoundedCorners':
            case 'HoverStyle':
            case 'IconAlignment':
                result = true;
                break;
            default:
                break;
        }
        return result;
    };


    this.renderHtml = function () {

        var html = '';

        html +=
            '<div class="widget-content widget-triggerButton">'
                + '<span class="widget-triggerButton-text" >Trigger Service: Invisible at runtime</span>'
          + '</div>';
        return html;
    };

    this.afterRender = function () {

    };
};
