/* bcwti
 *
 * Copyright (c) 2016-2020 PTC Inc.
 *
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC Inc. and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information and shall use
 * it only in accordance with the terms of the license agreement.
 *
 * ecwti
 */

/* var s_idePluginVersion = "0.50.2+MCHCFW"; */

TW.IDE.Widgets.thingview = function() {
    var thisWidget = this;
    this.widgetIconUrl = function() {
        return "../Common/extensions/ptc-thingview-extension/ui/thingview/pview.png";
    };

    var getLocalizedString = function(source, defaultValue) {
        var rtn = TW.IDE.convertLocalizableString(source);
        if (rtn == undefined || rtn == '???') {
            rtn = defaultValue;
        }
        return rtn;
    };

    this.widgetProperties = function() {
        return {
            'name': 'ThingView',
            'description': getLocalizedString('[[TW.ThingView.Description]]', 'The Creo View WebGL Widget allows 3-D models to be displayed.'),
            'category': ['Common', 'Components'],
            'isResizable': true,
            'supportsAutoResize': true,
            'properties': {
                'Width': {
                    'defaultValue': 300
                },
                'Height': {
                    'defaultValue': 200
                },
                'ProductToView': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.ProductToView.Description]]', 'The url of the file to load.')
                },
                'baseUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.BaseUrl.Description]]', 'The base url of the strucutre.')
                },
                'oid': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.Oid.Description]]', 'The oid of the strucutre.')
                },
                'mapUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.MapUrl.Description]]', 'The map file url.')
                },
                'markupUrl': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': false,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.MarkupUrl.Description]]', 'The url to markup content.')
                },
                'Orientations': {
                    'isBindingTarget': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.Orientations.Description]]', 'View orientations for the 3D view.'),
                    'baseType': 'STRING',
                    'defaultValue': 'ISO1',
                    'selectOptions': [
                        { value: 'ISO1', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.ISO1]]', 'ISO 1') },
                        { value: 'ISO2', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.ISO2]]', 'ISO 2') },
                        { value: 'Top', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.Top]]', 'Top') },
                        { value: 'Bottom', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.Bottom]]', 'Bottom') },
                        { value: 'Left', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.Left]]', 'Left') },
                        { value: 'Right', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.Right]]', 'Right') },
                        { value: 'Front', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.Front]]', 'Front') },
                        { value: 'Back', text: getLocalizedString('[[TW.ThingView.Properties.Orientations.SelectOptions.Back]]', 'Back') }
                    ]
                },
                'MouseNavigation': {
                    'isBindingTarget': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.MouseNavigation.Description]]', 'The mouse navigation mode to use in the 3D view'),
                    'baseType': 'STRING',
                    'defaultValue': 'CREOVIEW',
                    'selectOptions': [
                        { value: 'CREOVIEW', text: getLocalizedString('[[TW.ThingView.Properties.MouseNavigation.SelectOptions.CreoView]]', 'CreoView') },
                        { value: 'CREO', text: getLocalizedString('[[TW.ThingView.Properties.MouseNavigation.SelectOptions.Creo]]', 'Creo') },
                        { value: 'CATIAV5COMPATIBLE', text: getLocalizedString('[[TW.ThingView.Properties.MouseNavigation.SelectOptions.CATIA]]', 'CATIA V5 Compatible') },
                        { value: 'EXPLORE', text: getLocalizedString('[[TW.ThingView.Properties.MouseNavigation.SelectOptions.Explore]]', 'Explore') }
                    ]
                },
                'Orientation': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.Orientation.Description]]', 'Euler angles for camera orientation in X,Y,Z format (unit: degree). (For 90 degrees model rotation around Y-axis, specify 0,90,0)')
                },
                'Position': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.Position.Description]]', 'Camera position in X,Y,Z format (unit: meter). (For 0.5 meters distance along Y-axis from origin, specifiy 0,0.5,0)')
                },
                'BackgroundStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultShapeUnfilledBackgroundStyle',
                    'description': getLocalizedString('[[TW.ThingView.Properties.BackgroundStyle.Description]]', 'The background color used for the widget. All other fields ignored.')
                },
                'Data': {
                    'description': getLocalizedString('[[TW.ThingView.Properties.Data.Description]]', 'Part selection'),
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'OccurrenceField': {
                    'description': getLocalizedString('[[TW.ThingView.Properties.OccurrenceField.Description]]', 'Field in the Data that contains the Occurrence path id. Used to find rows for selection and coloring.'),
                    'baseType': 'FIELDNAME',
                    'baseTypeRestriction': "STRING",
                    'sourcePropertyName': 'Data',
                    'defaultValue': 'treeId'
                },
                'DataFormatter': {
                    'description': getLocalizedString('[[TW.ThingView.Properties.DataFormatter.Description]]', 'Rules for color in the widget. Only the Text Color will be used, both its color value and transparency setting. Set the transparency very low to hide parts for example. All other fields ignored.'),
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'Data'
                },
                'SelectedOccurrencePath': {
                    'description': getLocalizedString('[[TW.ThingView.Properties.SelectedOccurrencePath.Description]]', 'The Occurrence path that is last selected.'),
                    'baseType': 'STRING',
                    'isEditable': false,
                    'isBindingSource': true,
                    'isBindingTarget': false
                },
                'PreSelectedOccurrencePath': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.PreSelectedOccurrencePath.Description]]', 'The occurrence path of preselected part.'),
                    'warnIfNotBoundAsTarget': false
                },
                'Views': {
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isEditable': true,
                    'baseType': 'INFOTABLE',
                    'isVisible': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.Views.Description]]', 'A list of Views (Name, Type, Id).')
                },
                'Gnomon': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.Gnomon.Description]]', 'Display the Gnomon')
                },
                'EnablePartSelection': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.EnablePartSelection.Description]]', 'Allow part selection')
                },
                'EnablePartDragger': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.EnablePartDragger.Description]]', 'Allow the user to drag parts')
                },
                'SpinCenter': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.SpinCenter.Description]]', 'Display the Spin Center during rotation of model in the 3D view')
                },
                'AllowCORSCredentials': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.AllowCORSCredentials.Description]]', 'For CORS requests specify whether cookies will be added to the requests')
                },
                'AllowClientRedirect': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.AllowClientRedirect.Description]]', 'This property only applies if the ThingWorx server is using a media proxy. If set to true the widget will handle any http redirect requests to retrieve data directly from Windchill. If the value is false the media proxy will handle any Windchill redirect requests.')
                },
                'AcknowledgeStepText': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.AcknowledgeStepText.Description]]', 'The message to display when a sequence step requires an acknowledgement.')
                },
                'SequenceStepNumber': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.SequenceStepNumber.Description]]', 'The current sequence step number')
                },
                'SequenceStepName': {
                    'isBindingSource': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'isEditable': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.SequenceStepName.Description]]', 'The current sequence step name')
                },
                'WindchillSourceData': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.WindchillSourceData.Description]]', 'Set to true if ProductToView data is coming from Windchill otherwise set it to false.')
                },
                'EnableWindchillFileCache': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.EnableWindchillFileCache.Description]]', 'Set to true to enable part file cache from Windchill data source.')
                },
                'WindchillCacheSize': {
                    'baseType': 'NUMBER',
                    'isVisible': true,
                    'defaultValue': 1000,
                    'description': getLocalizedString('[[TW.ThingView.Properties.WindchillCacheSize.Description]]', 'Cache size in megabytes when using Windchill data source.')
                },
                'SelectedParts': {
                    'description': getLocalizedString('[[TW.ThingView.Properties.SelectedParts.Description]]', 'All the selected parts in the session'),
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isEditable': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'ThingViewControls': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.ThingViewControls.Description]]', 'Display the UI controls in ThingView')
                },
                'DisplayViewState': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.DisplayViewState.Description]]', 'Display viewstates in ThingViewControls')
                },
                'DisplayAlternateRep': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.DisplayAlternateRep.Description]]', 'Display alternate representations in ThingViewControls')
                },
                'DisplayExplodeState': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.DisplayExplodeState.Description]]', 'Display explode states in ThingViewControls')
                },
                'DisplaySectionCut': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': false,
                    'description': getLocalizedString('[[TW.ThingView.Properties.DisplaySectionCut.Description]]', 'Display section cuts in ThingViewControls')
                },
                'DisplayPlaybackControls': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.DisplayPlaybackControls.Description]]', 'Display playback controls in ThingViewControls')
                },
                'DisplayFilter': {
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '{ \"ModelAnnotation\": { \"HiddenByDefault\": true, \"PlanarAnnotation\": true, \"FloatingAnnotation\": false, \"MiscAnnotation\": false } }',
                    'description': getLocalizedString('[[TW.ThingView.Properties.DisplayFilter.Description]]', 'JSON string to specify display filters. i.e. { \"ModelAnnotation\": { \"HiddenByDefault\": true, \"PlanarAnnotation\": true, \"FloatingAnnotation\": false, \"MiscAnnotation\": false } }')
                },
                'ProjectionMode': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'description': getLocalizedString('[[TW.ThingView.Properties.ProjectionMode.Description]]', 'The projection mode to use in the 3D view'),
                    'baseType': 'STRING',
                    'defaultValue': 'ORTHOGRAPHIC',
                    'selectOptions': [
                        { value: 'PERSPECTIVE', text: getLocalizedString('[[TW.ThingView.Properties.ProjectionMode.SelectOptions.Perspective]]', 'Perspective') },
                        { value: 'ORTHOGRAPHIC', text: getLocalizedString('[[TW.ThingView.Properties.ProjectionMode.SelectOptions.Orthographic]]', 'Orthographic') }
                    ]
                },
                'PerspectiveHFOV': {
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'baseType': 'NUMBER',
                    'isVisible': true,
                    'defaultValue': 60,
                    'description': getLocalizedString('[[TW.ThingView.Properties.PerspectiveHFOV.Description]]', 'Horizontal field of view in perspective view')
                },
                'SelectionPropertyGroupName': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.SelectionPropertyGroupName.Description]]', 'Group name of selection property')
                },
                'SelectionPropertyName': {
                    'isBindingTarget': true,
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': '',
                    'description': getLocalizedString('[[TW.ThingView.Properties.SelectionPropertyName.Description]]', 'Name of selection property')
                },
                'SelectedPartsSelectionMode': {
                    'description': getLocalizedString('[[TW.ThingView.Properties.SelectedPartsSelectionMode.Description]]', 'Selection mode for selected parts'),
                    'baseType': 'STRING',
                    'defaultValue': 'IDPATH',
                    'selectOptions': [
                        { value: 'IDPATH', text: getLocalizedString('[[TW.ThingView.Properties.SelectedPartsSelectionMode.SelectOptions.IdPath]]', 'ID path') },
                        { value: 'PROPPATH', text: getLocalizedString('[[TW.ThingView.Properties.SelectedPartsSelectionMode.SelectOptions.PropPath]]', 'Property path') },
                        { value: 'PROPVALUE', text: getLocalizedString('[[TW.ThingView.Properties.SelectedPartsSelectionMode.SelectOptions.PropValue]]', 'Property value') }
                    ]
                }
            }
        };
    };

    this.customWidgetEvents = {
        'Loaded': {
            'description': getLocalizedString('[[TW.ThingView.CustomEvents.Loaded.Description]]', 'Triggered when loading a model is completed.')
        },
        'SelectionChanged': {
            'description': getLocalizedString('[[TW.ThingView.CustomEvents.SelectionChanged.Description]]', 'Triggered when selection is changed in 3D view or Data grid.')
        },
        'PreSelectionChanged': {
            'description': getLocalizedString('[[TW.ThingView.CustomEvents.PreSelectionChanged.Description]]', 'Triggered when preselection is changed in 3D view.')
        },
        'HasAnimation': {
            'description': getLocalizedString('[[TW.ThingView.CustomEvents.HasAnimation.Description]]', 'Triggered when loaded illustration has an animation.')
        },
        'HasSequence': {
            'description': getLocalizedString('[[TW.ThingView.CustomEvents.HasSequence.Description]]', 'Triggered when loaded illustration has a sequence.')
        },
        'SequenceStepAcknowledge': {
            'description': getLocalizedString('[[TW.ThingView.CustomEvents.SequenceStepAcknowledge.Description]]', 'Triggered when a sequence step has an acknowledgement')
        }
    };

    this.widgetServices = function() {
        return {
            'GetViewLocation': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.GetViewLocation.Description]]', 'Get the location (orientation and position) of the main camera in the 3D view.')
            },
            'SetViewLocation': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.SetViewLocation.Description]]', 'Move the main camera to be at the location given in the 3D view.')
            },
            'ZoomAll': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.ZoomAll.Description]]', 'Zoom so all visible parts and markups fill the view window.')
            },
            'ZoomSelected': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.ZoomSelected.Description]]', 'Zoom so all selected parts and markups fill the view window.')
            },
            'PlaySequenceStep': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.PlaySequenceStep.Description]]', 'Play the next step in the sequence.')
            },
            'PauseSequence': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.PauseSequence.Description]]', 'Pause the playback of the current step.')
            },
            'StopSequence': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.StopSequence.Description]]', 'Stop the playback of the current step.')
            },
            'RewindSequence': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.RewindSequence.Description]]', 'Go to the start of the first step in the sequence.')
            },
            'NextSequenceStep': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.NextSequenceStep.Description]]', 'Go to the end of the next step in the sequence.')
            },
            'PrevSequenceStep': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.PrevSequenceStep.Description]]', 'Go to the end of the previous step in the sequence.')
            },
            'PlayAnimation': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.PlayAnimation.Description]]', 'Play the animation.')
            },
            'PauseAnimation': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.PauseAnimation.Description]]', 'Pause the animation.')
            },
            'StopAnimation': {
                'warnIfNotBound': false,
                'description': getLocalizedString('[[TW.ThingView.Services.StopAnimation.Description]]', 'Stop the animation.')
            }
        };
    };

    this.widgetEvents = function() {
        return this.customWidgetEvents;
    };

    this.renderHtml = function() {
        var html = '';
        html += '<div class="widget-content widget-thingview"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span style="color: #5bb73b">ThingView</span></td></tr></table></div>';
        return html;
    };

    this.afterLoad = function () {
        TW.IDE.GetDataShapeInfo("Selection", function (info) {
            if (info) {
                var infoTable = {
                    'dataShape': info,
                    'rows': []
                };
                thisWidget.setProperty('SelectedParts', infoTable);
            }
        });

        TW.IDE.GetDataShapeInfo("Views", function (info) {
            if (info) {
                var infoTable = {
                    'dataShape': info,
                    'rows': []
                };
                thisWidget.setProperty('Views', infoTable);
            }
        });
    };

    this.afterSetProperty = function(name, value) {
        if (name === 'Width') {
            this.width = value;
            document.getElementById('pvCanvas').width = value;
        }
        else if (name === 'Height') {
            this.height = value;
            document.getElementById('pvCanvas').height = value;
        }
    };

    this.getSourceDatashapeName = function (propertyName) {
        if (propertyName === 'SelectedParts') {
            return 'Selection';
        } else if (propertyName == 'Views') {
            return 'Views';
        }

        return undefined;
    };
};