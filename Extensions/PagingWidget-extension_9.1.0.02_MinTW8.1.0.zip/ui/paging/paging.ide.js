/*global TW */  // For JSHint'ing

TW.IDE.Widgets.paging = function () {
    "use strict";

    this.widgetIconUrl = function () {
        return "../Common/extensions/PagingWidget-extension/ui/paging/paging.ide.png";
    };

    this.widgetProperties = function () {
        return {
            "name": "Paging",
            "description": "Provides paging for large datasets of assets",
            "category": ['Common'],
            "properties": {
                "CurrentPage": {
                    "baseType": "INTEGER",
                    "description" : "Which page to load (starts at zero)",
                    "defaultValue": 0,
                    "isBindingSource": true,
                    "isBindingTarget": true
                },
                "PageSize": {
                    "description": "Number of items in a page of data",
                    "baseType": "INTEGER",
                    "isBindingSource": true,
                    "defaultValue": 10
                },
                "TotalItems": {
                    "baseType": "INTEGER",
                    "defaultValue": 0,
                    "isBindingTarget": true,
                    "isEditable": false
                },
                "PageNumber": {
                    "baseType" : "INTEGER",
                    "defaultValue": 0,
                    "isBindingSource": true
                },
                "ItemsLabel": {
                    "baseType": "STRING",
                    "defaultValue": "Pages",
                    "isBindingTarget": true,
                    "isLocalizable": true
                },
                'VerticalAlignment': {
                    'baseType': 'STRING',
                    'defaultValue': 'middle',
                    'selectOptions': [
                        { value: 'bottom', text: 'Bottom' },
                        { value: 'middle', text: 'Middle' },
                        { value: 'top', text: 'Top' }
                    ]
                },
                'LabelStyle': {
                    'description': 'Default style of the items label',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMashupStyle'
                },
                'CurrentPageStyle': {
                    'description': 'Default style of the current page indicator',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMashupStyle'
                },
                'LinkStyle': {
                    'description': 'Default style of the navigation links',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLinkStyle'
                },
                'HoverStyle': {
                    'description': 'Style of the navigation links when hovered',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultLinkHoverStyle'
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
            'GetData': {'warnIfNotBound': true}
        };
    };

    this.renderHtml = function () {
        var cssStyle = " style='height:" + this.getProperty("ButtonHeight") + "px; width:" + this.getProperty("ButtonWidth") + "px'";
        var html = "<div class=\"widget-content widget-paging\">" +
            "<span class='items-label'>" + window.twHtmlUtilities.encodeHtml(this.getProperty("ItemsLabel")) + "</span>" +
            "<span class='page-controls'>&nbsp;|&nbsp;" +
                "<a class='previous-page pagingcontroller'>&nbsp;Previous&nbsp;</a>" +
                "<span class='previous-ellipsis'>&hellip;&nbsp;</span>" +
                "<a class='pagingcontroller'>1</a>&nbsp;" +
                "<span class='current-page'>2</span>&nbsp;" +
                "<a class='pagingcontroller'>3</a>&nbsp;" +
                "<span class='next-ellipsis'>&hellip;&nbsp;</span>" +
                "<a class='next-page pagingcontroller'>Next&nbsp;</a>" +
            "</span>" +
        "</div>";
        return html;
    };

    this.afterSetProperty = function (name, value) {
        return true;
    };
};
