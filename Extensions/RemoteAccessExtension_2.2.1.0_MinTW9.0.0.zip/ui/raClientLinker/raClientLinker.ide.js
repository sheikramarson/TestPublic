TW.IDE.Widgets.raClientLinker = function () {
  this.widgetProperties = function () {
    return {
      'name': 'RemoteAccessClientLinker',
      'description': 'Enables the creation of a deep link to the Thingworx Remote Access Client',
      'category': ['Common'],
      'dataSourceProperty': 'GUID',
      'defaultBindingTargetProperty': 'GUID',
      'supportsLabel': true,
      'supportsResetInputToDefault': true,
      'isExtension': true,
      'iconImage':'../../RemoteAccessExtension/ui/raClientLinker/images/remoteaccess.ide.svg',
      'properties': {
        RemoteEndpoint: {
          description:     'The remote endpoint to connect to',
          defaultValue:    '',
          baseType:        'STRING',
          isBindingTarget: true,
          isLocalizable:   true
        },
        ThingName: {
          description:     'Thing on which to start a session',
          defaultValue:    '',
          baseType:        'THINGNAME',
          isBindingTarget: true,
          isLocalizable:   true
        },
        ProviderConfig: {
          description:     'Provider-specific parameters to use when starting the session',
          defaultValue:    '',
          baseType:        'JSON',
          isBindingTarget: true,
          isLocalizable:   true
        },
        SessionId: {
          description:     'ID for a pre-started session. Widget will not start a new session if this property is set.',
          defaultValue:    '',
          baseType:        'GUID',
          isBindingSource: true,
          isBindingTarget: true,
          isLocalizable:   true
        },
        ErrorMessage: {
          description:     'If ClientLaunchFailed is fired, the error that occurred will be stored in this property.',
          defaultValue:    '',
          baseType:        'STRING',
          isBindingSource: true,
          isBindingTarget: false,
          isLocalizable:   false
        }
      }
    };
  };

  this.widgetEvents = function () {
    return {
      'SessionCreated': {},
      'AwaitingLaunch': {},
      'ClientLaunched': {},
      'ClientNotInstalled': {},
      'ClientLaunchFailed': {}
    }
  };

  this.widgetServices = function () {
      return {
          'LaunchClient': {
              'warnIfNotBound': false
          }
      }
  };

  this.renderHtml = function () {
    var html = '<div class="widget-content">' +
        'Remote Access Client Linker'
        '</div>';
    return html;
  };
};