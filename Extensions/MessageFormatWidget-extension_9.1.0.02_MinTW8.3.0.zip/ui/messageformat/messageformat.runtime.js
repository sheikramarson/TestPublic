TW.Runtime.Widgets.messageformat = function() {
    "use strict";
    var thisWidget = this;
    var lastValue = undefined;

    this.runtimeProperties = function() {
        return {
            'needsDataLoadingAndError': false
        };
    };

    this.afterRender = function() {
        // if we never show at runtime, we should hide ourselves completely - Safari and Firefox will show scrollbars if the container is too narrow / short
        this.jqElement.hide();
        this.jqElement.closest('.widget-bounding-box').hide();
    };

    this.doEvaluation = function() {
        var result = undefined;

        result = TW.Runtime.convertLocalizableString(thisWidget.getProperty('InputMessage'));
        for (var inputValuesNumber = 0; inputValuesNumber < thisWidget.getProperty('NumberOfValues'); inputValuesNumber++) {

            var props = thisWidget.getProperty('InputValue' + inputValuesNumber);
            if (props === undefined || props === '') {
                props = '';
            }
            var replace = "\{(" + inputValuesNumber + ")\}";
            var re = new RegExp(replace, "g");
            result = result.replace(re, props);
        }
        if (thisWidget.getProperty('EscapeHTML')) {
            result = TW.escapeHTML(result)
        }

        try {

            if (result != undefined) {
                if (this.getProperty('DataChangeType') == 'ALWAYS') {
                    thisWidget.setProperty('Output', result);

                    thisWidget.jqElement.triggerHandler("Changed");

                    this.lastValue = result;
                } else if (thisWidget.getProperty('DataChangeType') == 'VALUE' || thisWidget.getProperty('DataChangeType') == undefined) {
                    if (result != this.lastValue) {
                        thisWidget.setProperty('Output', result);
                        if (this.lastValue != undefined) {
                            thisWidget.jqElement.triggerHandler("Changed");
                        }

                        this.lastValue = result;
                    }
                }
            }

        } catch (eExecute) {
            TW.log.error('messageformat widget, error evaluating message "' + eExecute + '"');
        }
    };

    this.serviceInvoked = function(serviceName) {
        if (serviceName === 'Evaluate') {
            this.doEvaluation();
        } else {
            TW.log.error('messageformat widget, unexpected serviceName invoked "' + serviceName + '"');
        }
    };

    this.updateProperty = function(updatePropertyInfo) {
        this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
        if (this.getProperty('AutoEvaluate') === true) {
            this.doEvaluation();
        }
    };


    this.beforeDestroy = function() {
        thisWidget = null;
    };

    this.renderHtml = function() {
        //In case not fire first time
        if (this.getProperty('AutoEvaluate') === true) {
            this.doEvaluation();
        }
        return '<div class="widget-content widget-messageformat" style="display:none;"></div>';
    };
};
