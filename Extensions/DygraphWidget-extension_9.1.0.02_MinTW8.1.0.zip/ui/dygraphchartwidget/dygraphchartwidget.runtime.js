﻿/*global Encoder,TW */

var TW_dygraphchartwidgetIsExtension;
var GLOBAL_DYGRAPH_whoTriggeredSynchronize = "";
var dygraphInstances = [];
var syncInfo;

(function () {
    "use strict";
    // loader for extension libs
    $('head').append('<script>' +
                      'window.defineBackup = window.define;' +
                      'window.define = undefined;' +
                      '</script>' +
                      '<script type="text/javascript" src="../Common/extensions/DygraphWidget-extension/ui/dygraphchartwidget/include/dygraph.min.js"></script>' +
                      '<script>' +
                      'window.define = window.defineBackup;' +
                      '</script>');
    $('head').append('<script type="text/javascript" src="../Common/extensions/DygraphWidget-extension/ui/dygraphchartwidget/include/synchronizer.js"></script>');
    var d3Loaded = typeof window.d3 === "object",
        nvLoaded = typeof window.nv === "object";
    // test loop for d3 loaded

    var addedDefaultChartStyles = false;

    TW.Runtime.Widgets.dygraphchartwidget = function () {
        var thisWidget = this,
			domElement,
            liveData,
            widgetProperties,
            widgetContainer,
			widgetElement,
            widgetContainerId,
			serieVisibility = [],
            chartTitleTextSizeClass,
            chartTitleStyle,
			chartTable,
			showDecimal = true,
            mashupParamDataSources = false;

        thisWidget.dynamicSeries = undefined;
        thisWidget.singleDataSource = thisWidget.getProperty('SingleDataSource');
        thisWidget.title = thisWidget.getProperty('ChartTitle');
        thisWidget.xlabel = thisWidget.getProperty('XLabel');
        thisWidget.ylabel = thisWidget.getProperty('YLabel');
        thisWidget.y2label = thisWidget.getProperty('Y2Label');
        thisWidget.titleAlignment = thisWidget.getProperty("ChartTitleAlignment");
        thisWidget.xAxisLabel = thisWidget.getProperty('X-AxisLabel');
        thisWidget.yAxisLabel = thisWidget.getProperty('Y-AxisLabel');
        thisWidget.HideYAxisValues = thisWidget.getProperty('HideY-AxisValues');
        thisWidget.showZoomStrip = thisWidget.getProperty('ShowZoomStrip');
        thisWidget.showLegend = thisWidget.getProperty('ShowLegend');
        thisWidget.Stepped = thisWidget.getProperty('Stepped');
        thisWidget.custombar = thisWidget.getProperty('CustomBars');
        thisWidget.fillArea = Boolean(thisWidget.getProperty('FillArea'));
        thisWidget.fillAreaTrans = thisWidget.getProperty('FillAreaTrans');
        thisWidget.StackedGraph = Boolean(thisWidget.getProperty('StackedGraph'));
        thisWidget.labelAngle = thisWidget.getProperty('LabelAngle')*-1;
        thisWidget.xAxisIntervals = thisWidget.getProperty('X-AxisIntervals');
        thisWidget.xAxisMinMaxVisible = Boolean(thisWidget.getProperty('ShowX-AxisMinMax'));
        thisWidget.yAxisMinimum = thisWidget.getProperty('YAxisMinimum')*1;
        thisWidget.yAxisMaximum = thisWidget.getProperty('YAxisMaximum')*1;
        thisWidget.autoScale = Boolean(thisWidget.getProperty('AutoScale'));
        thisWidget.yAxisIntervals = thisWidget.getProperty('YAxisIntervals');
        thisWidget.yAxisMinMaxVisible = thisWidget.getProperty('ShowY-AxisMinMax');
        thisWidget.margins = thisWidget.getProperty('Margins');
        thisWidget.width = thisWidget.getProperty('Width');
        thisWidget.height = thisWidget.getProperty('Height');
        thisWidget.zIndex = thisWidget.getProperty('Z-index');
        thisWidget.selectedItems = [];
        thisWidget.enableSelection = true;
        thisWidget.toggleScaling = true;
        thisWidget.xAxisField = thisWidget.getProperty('X-AxisField');
        thisWidget.timeScale = thisWidget.getProperty('TimeScale');
        thisWidget.timeFormat = thisWidget.timeScale==='y' ? thisWidget.getProperty('DateOrder') : thisWidget.timeScale;
        thisWidget.reSort = thisWidget.getProperty('Re-Sort');
        thisWidget.json = thisWidget.getProperty('JSONData');
        thisWidget.isDateFormat = thisWidget.getProperty('useDateFormat');
        thisWidget.dateFormat = thisWidget.getProperty('dateFormat');
		thisWidget.LegendPosition = thisWidget.getProperty('LegendPosition');
        showDecimal = thisWidget.getProperty('showDecimal');
        thisWidget.UsePercentageFormat = thisWidget.getProperty('UsePercentageFormat');
        thisWidget.useValueRange = thisWidget.getProperty('useValueRange');
        thisWidget.valueRangeMax = thisWidget.getProperty('valueRangeMax');
        thisWidget.valueRangeMin = thisWidget.getProperty('valueRangeMin');
        thisWidget.ann = thisWidget.getProperty('annotationsJSON');
        thisWidget.dateWinStart = Date.parse(thisWidget.getProperty('DateWindowStart'));
        thisWidget.dateWinEnd = Date.parse(thisWidget.getProperty('DateWindowEnd'));
        thisWidget.annData = null;
        thisWidget.seriesOpt = {};
        thisWidget.seriesObj = {};
        thisWidget.seriesLegendVis = {};
        thisWidget.annDivName = thisWidget.getProperty('annotationsDivName');
        thisWidget.useAnnotation = thisWidget.getProperty('useAnnotation');
        thisWidget.stopTriggerZoom = false;
        thisWidget.enableZoomSynchronizing = thisWidget.getProperty('EnableZoomSynchronizing');
        thisWidget.disableVerticalZoom = thisWidget.getProperty('DisableVerticalZoom');
        thisWidget.connectPoints = thisWidget.getProperty('ConnectSeparatedPoints');
        thisWidget.DisplayTagName = thisWidget.getProperty('DisplayTagName');
        thisWidget.drawPoints = thisWidget.getProperty('DrawPoints');
        thisWidget.defaultSynch = thisWidget.getProperty('DygraphSynchDefault');

        if (thisWidget.connectPoints == undefined) {
            thisWidget.connectPoints = true;
        }
        if (thisWidget.drawPoints == undefined) {
            thisWidget.drawPoints = false;
        }
        if(thisWidget.DisplayTagName == undefined) {
            thisWidget.DisplayTagName = false;
        }


		thisWidget.drawX = thisWidget.getProperty('DrawAxisX');
		thisWidget.drawY = thisWidget.getProperty('DrawAxisY');
		thisWidget.drawY2 = thisWidget.getProperty('DrawAxisY2');

        if (thisWidget.useValueRange == undefined || !thisWidget.useValueRange){
            thisWidget.valueRangeMax = null;
            thisWidget.valueRangeMin = null;
        }

		if (thisWidget.drawX == undefined){
			thisWidget.drawX = true;
		}
		if (thisWidget.drawY == undefined){
			thisWidget.drawY = true;
		}
		if (thisWidget.drawY2 == undefined){
			thisWidget.drawY2 = true;
		}

		//set transparency of the filled area
         var alpha = parseFloat(thisWidget.fillAreaTrans);
         if (!isNaN(alpha) && alpha >= 0.0 && alpha <= 1.0) {
             thisWidget.fillAreaTrans = alpha;
         } else {
             thisWidget.fillAreaTrans = 0.15;
         }

		for (var i = 0; i<9; i++){
			serieVisibility[i] = thisWidget.getProperty('SeriesVisibility' + (1 + i));
			thisWidget.seriesObj['DataLabel'+(i+1)] = thisWidget.getProperty('DataLabel' + (1 + i));
			thisWidget.seriesObj['SeriesSecondAxis'+(i+1)] = thisWidget.getProperty('SeriesSecondAxis' + (1 + i));
            thisWidget.seriesLegendVis[i+1] = thisWidget.getProperty('HideSeries' + (i+1) + 'InLegend') == undefined
             ? false : thisWidget.getProperty('HideSeries' + (i+1) + 'InLegend');
		}

        thisWidget.DrawGridX = (thisWidget.getProperty('DrawGridX') === undefined) ? true : thisWidget.getProperty('DrawGridX');
        thisWidget.DrawGridY = (thisWidget.getProperty('DrawGridY') === undefined) ? true : thisWidget.getProperty('DrawGridY');
        thisWidget.DrawGridY2 = (thisWidget.getProperty('DrawGridY2') === undefined) ? true : thisWidget.getProperty('DrawGridY2');

		//Get Colors for Chart
		var chartStyle1 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle1','DefaultChartStyle1'));
		var chartStyle2 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle2','DefaultChartStyle2'));
		var chartStyle3 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle3','DefaultChartStyle3'));
		var chartStyle4 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle4','DefaultChartStyle4'));
		var chartStyle5 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle5','DefaultChartStyle5'));
		var chartStyle6 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle6','DefaultChartStyle6'));
		var chartStyle7 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle7','DefaultChartStyle7'));
		var chartStyle8 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle8','DefaultChartStyle8'));
		var chartStyle9 = TW.getStyleFromStyleDefinition(thisWidget.getProperty('SeriesStyle9','DefaultChartStyle9'));

		chartTable = [chartStyle1.lineColor, chartStyle2.lineColor, chartStyle3.lineColor, chartStyle4.lineColor, chartStyle5.lineColor, chartStyle6.lineColor, chartStyle7.lineColor, chartStyle8.lineColor, chartStyle9.lineColor];

        // Overwrite with hex colors if provided
        var hexColors = thisWidget.getProperty('HexColors','')
        if(hexColors.length > 0){
            chartTable = hexColors.split(",");
        }

        this.runtimeProperties = function () {
            return {
                'needsDataLoadingAndError': false
            };
        };

        this.renderHtml = function () {
            chartTitleStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ChartTitleStyle', 'DefaultChartTitleStyle'));

            chartTitleTextSizeClass = 'textsize-normal';
            if (this.getProperty('ChartTitleStyle') !== undefined) {
                chartTitleTextSizeClass = TW.getTextSizeClassName(chartTitleStyle.textSize);
            }

            thisWidget.id = thisWidget.getProperty('Id');
            var html =
                '<div class="widget-content widget-dygraphchartwidget" id="' + this.jqElementId + '" style=" z-index: '+thisWidget.zIndex +';" >' +
                '<div id="dygraph"></div>'+
				'</div>';


            return html;
        };

        this.applyTwoAxisOption = function () {
            for (var i = 1;i<=9;i++){
                if (thisWidget.seriesObj['DataLabel' + i] !== undefined){
                    thisWidget.seriesOpt[thisWidget.seriesObj['DataLabel' + i]] = { axis: thisWidget.seriesObj['SeriesSecondAxis' + i] };
                }
            }
            thisWidget.dygraphGraph.updateOptions({
                series : thisWidget.seriesOpt
            });

        };

        this.afterRender = function () {
			var widgetReference = this;
            widgetProperties = thisWidget.properties;
            widgetContainer = thisWidget.jqElementId;
			widgetElement = this.jqElement;
            widgetContainerId = '#' + thisWidget.jqElementId;
			domElement = this.domElement;
            // look to see if chart is in a mashupContainer
            // class contains widget-mashupcontainer
            mashupParamDataSources = $(widgetContainerId).parents('.widget-mashupcontainer').length;

            var widgetSelector = widgetContainer + ' .-element';
            // add svg tag to html element required to inject chart
            // styles
            var chartTitleElement = $(widgetContainerId).find('.chart-title');
            chartTitleElement.switchClass('textsize-normal', chartTitleTextSizeClass);

			widgetElement.on('zoom', function() {
				 widgetReference.setProperty('zoomMax',thisWidget.maxX);
				 widgetReference.setProperty('zoomMin',thisWidget.minX);
				 widgetReference.setProperty('isZoomed',true);
                 // Jon - Aug 03
				 widgetElement.triggerHandler('Zoomed');
                 GLOBAL_DYGRAPH_whoTriggeredSynchronize = widgetContainerId;
                 widgetElement.triggerHandler('SyncRequest');
			});

			widgetElement.on('unzoom', function() {
				 widgetReference.setProperty('isZoomed',false);
				 thisWidget.doZoomY();

				 if (thisWidget.stopTriggerZoom == false){
                    // Jon - Aug 03
				 	//widgetElement.triggerHandler('DoubleClicked');
                    GLOBAL_DYGRAPH_whoTriggeredSynchronize = widgetContainerId;
                    widgetElement.triggerHandler('SyncRequest');
				 }

			});

            // events
            $(widgetSelector).on('focus', function () {
                //console.log("focus");
                $(widgetContainer).addClass('focus');
            });

            $(widgetSelector).on('blur', function (e) {
                //console.log("blur");
                $(widgetContainer).removeClass('focus');
            });

			thisWidget.jqElement.dblclick(thisWidget.dblClickHandler);
        };

        this.updateProperty = function (updatePropertyInfo) {
            var thisWidget = this;

			if (updatePropertyInfo.TargetProperty === "JSONData"){
				liveData = updatePropertyInfo.RawSinglePropertyValue;
				//
				if (thisWidget.currentData != null){
					if (liveData == undefined || liveData == ""){
					    liveData = "X\n";
					}
					thisWidget.currentData = liveData;
					thisWidget.dygraphGraph.updateOptions({
						'file': liveData
					});
				} else {
					this.render(liveData);
				}
				//liveData = this.json;
			}
			if (updatePropertyInfo.TargetProperty === "zoomMax" ||
				updatePropertyInfo.TargetProperty === "zoomMin"){
				this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);

			}
			if (updatePropertyInfo.TargetProperty.indexOf('SeriesVisibility') != -1 ){
				this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
				var numStr = updatePropertyInfo.TargetProperty.slice(-1);
				var num = parseInt(numStr);
				var newStat = (updatePropertyInfo.SinglePropertyValue == "true");
				serieVisibility[num-1] = newStat;
				thisWidget.dygraphGraph.setVisibility(num-1,newStat);
			}

            if (updatePropertyInfo.TargetProperty === "SeriesVisibilities"){
				this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
                if(updatePropertyInfo.SinglePropertyValue.length > 0){
                    var seriesVisibilities = updatePropertyInfo.SinglePropertyValue.split(",");
                    for (var i = 0; i < seriesVisibilities.length; i++) {
                        var isVisible = (seriesVisibilities[i].indexOf("true")>-1);
                        serieVisibility[i] = isVisible;
                        thisWidget.dygraphGraph.setVisibility(i,isVisible);
                    }
                }
			}

			if (updatePropertyInfo.TargetProperty === "isZoomed"){
				var newZoom = (updatePropertyInfo.SinglePropertyValue == "true");
				this.setProperty('isZoomed',newZoom);
			}

			if (updatePropertyInfo.TargetProperty === "valueRangeMax"){
				this.setProperty('valueRangeMax',updatePropertyInfo.SinglePropertyValue);
				thisWidget.valueRangeMax = updatePropertyInfo.SinglePropertyValue;
                var options = {};
                options.valueRange = [thisWidget.valueRangeMin, thisWidget.valueRangeMax];
                thisWidget.dygraphGraph.updateOptions(options);
			}

            if (updatePropertyInfo.TargetProperty === "DateWindowStart"){
                thisWidget.dateWinStart =  Date.parse(updatePropertyInfo.SinglePropertyValue);
                var options = {};
                options.dateWindow = [thisWidget.dateWinStart, thisWidget.dateWinEnd];
                thisWidget.dygraphGraph.updateOptions(options);
            }

            if (updatePropertyInfo.TargetProperty === "DateWindowEnd"){
                thisWidget.dateWinEnd =  Date.parse(updatePropertyInfo.SinglePropertyValue);
                var options = {};
                options.dateWindow = [thisWidget.dateWinStart, thisWidget.dateWinEnd];
                thisWidget.dygraphGraph.updateOptions(options);
            }

			if (updatePropertyInfo.TargetProperty === "EnableZoomSynchronizing"){
				var isZoomSyncEnabled = (updatePropertyInfo.SinglePropertyValue == "true");
				thisWidget.enableZoomSynchronizing = isZoomSyncEnabled;
			}
			if (updatePropertyInfo.TargetProperty === "annotationsJSON"){
			    var jsonStr = updatePropertyInfo.RawSinglePropertyValue;
                var annJson =JSON.parse(jsonStr);
                thisWidget.annData = annJson;
			    thisWidget.dygraphGraph.setAnnotations(annJson);
			}
            if (updatePropertyInfo.TargetProperty.includes("SeriesSecondAxis") || updatePropertyInfo.TargetProperty.includes("DataLabel")){
                var value = updatePropertyInfo.SinglePropertyValue;
                if (updatePropertyInfo.SinglePropertyValue == "true"){
                    value = 'y2';
                }
                else if (updatePropertyInfo.SinglePropertyValue == "false"){
                    value = 'y1';
                }
                thisWidget.seriesObj[updatePropertyInfo.TargetProperty] = value;
                thisWidget.applyTwoAxisOption();
            }
            if (updatePropertyInfo.TargetProperty === "HexColors"){
				this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
				if(updatePropertyInfo.SinglePropertyValue.length > 0){
                    chartTable = updatePropertyInfo.SinglePropertyValue.split(",");
                    this.render(liveData);
                }
			}
        };

		this.serviceInvoked = function (serviceName) {
            var widgetReference = this;

            if (serviceName === 'resetZoom') {
                //console.log('SERVICE TRIGGERED: '+serviceName+ ' : ' +thisWidget.id);
                thisWidget.stopTriggerZoom = true;
                thisWidget.dygraphGraph.resetZoom();
                widgetElement.trigger("unzoom");
                thisWidget.stopTriggerZoom = false;
            }
            if (serviceName === 'sync') {
                //console.log('SERVICE TRIGGERED: '+serviceName+ ' : ' +thisWidget.id);
                if (thisWidget.enableZoomSynchronizing == true && GLOBAL_DYGRAPH_whoTriggeredSynchronize != ""){
                    console.log('Synching "' + widgetReference.id + '" with "' + GLOBAL_DYGRAPH_whoTriggeredSynchronize.split("_")[2] + '"');
                    var sourceDygraph = $(GLOBAL_DYGRAPH_whoTriggeredSynchronize).data().widget;
                    var sourceZoomMin = sourceDygraph.getProperty('zoomMin');
                    var sourceZoomMax = sourceDygraph.getProperty('zoomMax');
                    var sourceIsZoomed = sourceDygraph.getProperty('isZoomed');
                    thisWidget.stopTriggerZoom = true;
                    if (sourceIsZoomed == true){
                        thisWidget.dygraphGraph.doZoomXDates_(sourceZoomMin, sourceZoomMax);
                        thisWidget.setProperty('zoomMax',thisWidget.maxX);
                        thisWidget.setProperty('zoomMin',thisWidget.minX);
                        thisWidget.setProperty('isZoomed',true);
                    } else {
                        thisWidget.dygraphGraph.resetZoom();
                        widgetElement.trigger("unzoom");
                    }
                    thisWidget.stopTriggerZoom = false;
                }
            }
            if (serviceName === 'dygraphSynchronize' && dygraphInstances.length > 1){
                syncInfo = Dygraph.synchronize(dygraphInstances,
                {
                range:false
                });
            }
            if (serviceName === 'detach'){
                syncInfo.detach();
            }

        };

		this.ZoomedCalled = function (minX, maxX, yRanges){
			thisWidget.minX = minX;
			thisWidget.maxX = maxX;
			if (thisWidget.disableVerticalZoom == false) {
				var ranges = yRanges[0];
				thisWidget.valueRangeMin = ranges[0];
				thisWidget.valueRangeMax = ranges[1];
			}
			//console.log('Attempting triggerZoom - ' +thisWidget.id);
			if (thisWidget.stopTriggerZoom == false){
				//console.log('ZoomedCalled: triggerZoom - ' +thisWidget.id);
				widgetElement.trigger("zoom");
			}
		};

        this.render = function (data, isUpdate) {
            if (data == undefined || liveData == ""){//Send the correct empty data format if empty.
                data = "X\n";
            }
			thisWidget.currentData = data;
			Dygraph.SHORT_MONTH_NAMES_ = (TW.Runtime.convertLocalizableString('[[datepickerMonthShortNames]]')).split(",");
			thisWidget.dygraphGraph = new Dygraph(
			document.getElementById(this.jqElementId),
			data,
				{
					customBars: thisWidget.custombar,
					title: thisWidget.title,
					legend: thisWidget.LegendPosition,
					labelsDivStyles: { 'textAlign': 'right' },
					xlabel: thisWidget.xlabel,
					ylabel: thisWidget.ylabel,
					y2label: thisWidget.y2label,
					drawAxesAtZero: false,
					stepPlot: thisWidget.Stepped,
					labelsSeparateLines: true,
					//labels: dataLabels,
					colors: chartTable,
					fillGraph: thisWidget.fillArea,
					fillAlpha: thisWidget.fillAreaTrans,
					stackedGraph: thisWidget.StackedGraph,
					connectSeparatedPoints: thisWidget.connectPoints,
					drawPoints: thisWidget.drawPoints,
					legendFormatter: function(data) {
					    if (data.x == null) {
                            // This happens when there's no selection and {legend: 'always'} is set.
                            return '<br>' + data.series.map(function(series) { return series.dashHTML + ' ' + series.labelHTML }).join('<br>');
                        }

                        var counter = 0;
					    var html = data.xHTML;

					    data.series.forEach(function(series) {
					        counter++;
					        if (!series.isVisible) return;

					        if(counter > 0 && thisWidget.seriesLegendVis[counter] == false) {
					            if(thisWidget.DisplayTagName == true) {
                                    html += '<br>' + series.dashHTML + ' ' + series.labelHTML + ': ' + series.yHTML;
                                }
                                else{
                                 html += '<br>' + series.dashHTML + ' ' + series.yHTML;
                                }
					        }
					    });

                        return html;
                    },
					visibility: serieVisibility,
					height:thisWidget.height,
					width:thisWidget.width,
					digitsAfterDecimal: 4,
					valueRange : [thisWidget.valueRangeMin, thisWidget.valueRangeMax],
					zoomCallback: function(minX, maxX, yRanges) {
						thisWidget.ZoomedCalled(minX,maxX,yRanges);
						thisWidget.doZoomY();
					},
                    drawCallback: function(g) {
                        if (thisWidget.useAnnotation) {
                            var ann = g.annotations();
                            var html = "";
                            var annDiv = document.getElementById(thisWidget.annDivName);
                            if (ann.length > 0  && annDiv != null){
                                for (var i = 0; i < ann.length; i++) {
                                  var name = thisWidget.nameAnnotation(ann[i]);
                                  html += "<span id='" + name + "' style='display:none'>";
                                  html += ann[i].customInfo;
                                  html += "<br/></span>";
                                }
                                annDiv.innerHTML = html;
                            }
                        }
                    },
                    axes: {
                        y: {
                            drawGrid: thisWidget.DrawGridY,
                            drawAxis: this.drawY,
                            axisLabelFormatter: function(y, gran, opts) {
                                if (!thisWidget.HideYAxisValues) {
                                    if (thisWidget.UsePercentageFormat){
                                        return Math.round(y * 100) + "%";
                                    }
                                    if (!showDecimal && y % 1 != 0){
                                        return "";
                                    }
                                    return Math.round(y * 100) / 100;
                                }
                                return "";
                            },
                            // display percentage values in legend
                            valueFormatter: function (y) {
                                if (thisWidget.UsePercentageFormat){
                                    return y * 100 + "%";
                                }
                                return y;
                            }
                        },
                        x: {
                            drawGrid: thisWidget.DrawGridX,
                            drawAxis: this.drawX,
                            axisLabelFormatter: function(date,gran,opts){
                                if (!thisWidget.isDateFormat){
                                    if (!isNaN(date)){
                                        date = new Date(date);
                                    }
                                    return Dygraph.dateAxisLabelFormatter(date,gran,opts);
                                }
                                return moment(date).format(thisWidget.dateFormat);
                            },
                            // Format the date in the Dygraph Legend (tooltip thingy)
                            valueFormatter: function (ms) {
                                var legendDate = new Date(ms);
                                var legendDateString = legendDate.toLocaleDateString() + " " + legendDate.toLocaleTimeString([],{hour12:false});
                                return legendDateString;
                            }
                        },
						y2: {
                            drawGrid: thisWidget.DrawAxisY2,
                            drawAxis: thisWidget.drawY2,
                            independentTicks: true,
                            gridLineColor: "#ff0000",
                            gridLinePattern: [4,4],
                            axisLabelFormatter: function(y, gran, opts) {
                                if (!thisWidget.HideYAxisValues) {
                                    if (thisWidget.UsePercentageFormat){
                                        return Math.round(y * 100) + "%";
                                    }
                                    if (!showDecimal && y % 1 != 0){
                                        return "";
                                    }
                                    return Math.round(y * 100) / 100;
                                }
                                return "";
                            },
                            // display percentage values in legend
                            valueFormatter: function (y) {
                                if (thisWidget.UsePercentageFormat){
                                    return y * 100 + "%";
                                }
                                return y;
                            }
                        }
                    }
				}
			);
            dygraphInstances.push(thisWidget.dygraphGraph);

            if (thisWidget.annData != null){
                thisWidget.dygraphGraph.setAnnotations(thisWidget.annData);
            }


            thisWidget.applyTwoAxisOption();

            thisWidget.dygraphGraph.updateOptions({
                'file': liveData,
                annotationClickHandler: function(ann, point, dg, event) {
                    $('#' + thisWidget.annDivName +' > *').css('display', 'none');
                    document.getElementById(thisWidget.nameAnnotation(ann)).style.display = "block";
                },
                    annotationDblClickHandler: function(ann, point, dg, event) {
                    document.getElementById(thisWidget.nameAnnotation(ann)).style.display = "none";

                }
            });
            if (thisWidget.dateWinStart && thisWidget.dateWinEnd){
                var options = {};
                options.dateWindow = [thisWidget.dateWinStart, thisWidget.dateWinEnd];
                thisWidget.dygraphGraph.updateOptions(options);
            }

            if (thisWidget.defaultSynch && dygraphInstances.length > 1){
                syncInfo = Dygraph.synchronize(dygraphInstances,
               {
               range:false
               });
            }
        };

        this.nameAnnotation = function (ann) {
            return "(" + ann.series + ", " + ann.x + ")";
        };

        this.update = function (data){
            // Update the SVG with the new data and call chart
           // chartData.datum(data).transition().duration(500).call(chart);
           // nv.utils.windowResize(chart.update);
        };

        this.dblClickHandler = function(){
        	//console.log('DblClickCalled: ' +thisWidget.id);
			widgetElement.trigger("unzoom");
            thisWidget.jqElement.triggerHandler('DoubleClicked');
            if (thisWidget.dateWinStart && thisWidget.dateWinEnd){
                var options = {};
                options.dateWindow = [thisWidget.dateWinStart, thisWidget.dateWinEnd];
                thisWidget.dygraphGraph.updateOptions(options);
            }
        };

        this.showEmptyChart = function (message) {
            console.log(message);
        };

        this.doZoomY = function() {
        	var options = {};
			options.valueRange = [thisWidget.valueRangeMin, thisWidget.valueRangeMax];
			thisWidget.dygraphGraph.updateOptions(options);
        };

        //Format function for the tooltip values column
        this.valueFormatter = function(d,i) {
            return d;
        };

        //Format function for the tooltip header value.
        this.headerFormatter = function(d) {
            return d;
        };

        this.keyFormatter = function(d, i) {
            return d;
        };

        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
                dygraphInstances = [];
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.button.beforeDestroy', err);
            }
        };

    };
}());
