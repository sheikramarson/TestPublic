/*global TW */

TW.IDE.Widgets.propertytable = function () {
    this.widgetIconUrl = function() {
        return  "../Common/extensions/propertytable_ExtensionPackage/ui/propertytable/propertytable.ide.png";
    };

    this.widgetProperties = function () {
        return {
            name:                         'Property Table',
            description:                  'Display properties and their values in a styled table.',

            category:                     ['Common', 'Data'],
            // customEditor:                 'TODO',
            // customEditorMenuText:         'Configure Rows',
            defaultBindingTargetProperty: 'Data',
            supportsAutoResize:           true,

            properties: {
                // Data source.
                Data: {
                    description:            'Data source: table of properties, types, and values.',
                    baseType:               'INFOTABLE',
                    isBindingTarget:        true,
                    isEditable:             false,
                    warnIfNotBoundAsTarget: true
                },
                // Grid style -- border color and width, background for container.
                PropertyTableBackgroundStyle: {
                    description:  'Style for grid lines and widget background.',
                    baseType:     'STYLEDEFINITION',
                    defaultValue: 'DefaultGridBackgroundStyle'
                },
                // Property style -- text font, size, color, decoration.
                PropertyStyle: {
                    description:  'Text style for the Property column.',
                    baseType:     'STYLEDEFINITION',
                    defaultValue: 'DefaultLabelStyle'
                // Value style -- text font, size, color, decoration.
                },
                ValueStyle: {
                    description:  'Text style for the Value column.',
                    baseType:     'STYLEDEFINITION',
                    defaultValue: 'DefaultValueDisplayStyle'
                },
                // Odd row style -- background colors.
                RowBackgroundStyle: {
                    description:  'Background for odd-numbered rows.',
                    baseType:     'STYLEDEFINITION',
                    defaultValue: 'DefaultRowBackgroundStyle'
                },
                // Even row style -- background colors.
                RowAlternateBackgroundStyle: {
                    description:  'Background for even-numbered rows.',
                    baseType:     'STYLEDEFINITION',
                    defaultValue: 'DefaultRowAlternateBackgroundStyle'
                },
                // Hover style -- background colors.
                RowHoverStyle: {
                    description:  'Background for row when hovered over.',
                    baseType:     'STYLEDEFINITION',
                    defaultValue: 'DefaultRowHoverStyle'
                },
                // Column relative widths.
                PropertyColumnWidth: {
                    description: 'Percentage width of Property column.',
                    baseType: 'NUMBER',
                    defaultValue: 50
                },
                // Dimensions.
                Width: {
                    description: 'Property table width',
                    defaultValue: 400
                },
                Height: {
                    description: 'Property table height',
                    defaultValue: 200
                }
                // TODO add a configuration property for row labels, selection, etc.
            }
        };
    };

    this.afterRender = function () {
        // Create HTML for displaying a sample table in Composer.

        var sampleTemplate = _.template(
            '<div class="widget-content widget-propertytable" style="<%= div %>">' +
                '<table width="100%">' +
                    '<tr style="<%= row %>">' +
                        '<td style="<%= prop %> <%= borders %> <%= cellPadding %> width:<%= propWidth %>%;">' +
                            '<span class="<%= propClass %>">Property 1</span>' +
                        '</td>' +
                        '<td style="<%= val %> <%= borders %> <%= cellPadding %>">' +
                            '<span class="<%= valClass %>">Value 1</span>' +
                        '</td>' +
                    '</tr>' +
                    '<tr style="<%= altRow %>">' +
                        '<td style="<%= prop %> <%= borders %> <%= cellPadding %>">' +
                            '<span class="<%= propClass %>">Property 2</span>' +
                        '</td>' +
                        '<td style="<%= val %> <%= borders %> <%= cellPadding %>">' +
                            '<span class="<%= valClass %>">Value 2</span>' +
                        '</td>' +
                    '</tr>' +
                    '<tr style="<%= row %>">' +
                        '<td style="<%= prop %> <%= borders %> <%= cellPadding %>">' +
                            '<span class="<%= propClass %>">Property 3</span>' +
                        '</td>' +
                        '<td style="<%= val %> <%= borders %> <%= cellPadding %>">' +
                            '<span class="<%= valClass %>">Value 3</span>' +
                        '</td>' +
                    '</tr>' +
                    '<tr style="<%= altRow %>">' +
                        '<td style="<%= prop %> <%= borders %> <%= cellPadding %>">' +
                            '<span class="<%= propClass %>">Property 4</span>' +
                        '</td>' +
                        '<td style="<%= val %> <%= borders %> <%= cellPadding %>">' +
                            '<span class="<%= valClass %>">Value 4</span>' +
                        '</td>' +
                    '</tr>' +
                '</table>' +
            '</div>'
            );

        var styles = {};

        // Extract useful style attributes from current property values.

        var aStyle = TW.getStyleFromStyleDefinition(this.getProperty('PropertyTableBackgroundStyle'));
        styles.div = TW.getStyleCssGradientFromStyle(aStyle);
        styles.borders = TW.getStyleCssBorderFromStyle(aStyle);

        aStyle = TW.getStyleFromStyleDefinition(this.getProperty('RowBackgroundStyle'));
        styles.row = TW.getStyleCssGradientFromStyle(aStyle);

        aStyle = TW.getStyleFromStyleDefinition(this.getProperty('RowAlternateBackgroundStyle'));
        styles.altRow = TW.getStyleCssGradientFromStyle(aStyle);

        aStyle = TW.getStyleFromStyleDefinition(this.getProperty('PropertyStyle'));
        styles.prop = TW.getStyleCssTextualNoBackgroundFromStyle(aStyle);
        styles.propClass = TW.getTextSizeFromStyleDefinition(this.getProperty('PropertyStyle'));
        styles.propWidth = this.getProperty('PropertyColumnWidth', 50);

        aStyle = TW.getStyleFromStyleDefinition(this.getProperty('ValueStyle'));
        styles.val = TW.getStyleCssTextualNoBackgroundFromStyle(aStyle);
        styles.valClass = TW.getTextSizeFromStyleDefinition(this.getProperty('ValueStyle'));

        // TODO padding should be a property but there's no precedent for exposing it.
        styles.cellPadding = 'padding: 2px 4px;';

        // Update the sample display.

        this.jqElement.html(sampleTemplate(styles));
    };

    this.afterSetProperty = function (name, value) {

        var result = false;
        var limitValue = -1;

        switch (name) {
            case 'Height':
            case 'PropertyColumnWidth':
            case 'PropertyStyle':
            case 'PropertyTableBackgroundStyle':
            case 'RowAlternateBackgroundStyle':
            case 'RowBackgroundStyle':
            case 'ValueStyle':
            case 'Width':
                result = true; // refresh composer's rendition
                break;
        }

        return result;
    };

    this.beforeSetProperty = function (name, value) {
        switch (name) {
            case 'PropertyColumnWidth':
                if (value < 5) {
                    return "Must be at least 5";
                }
                else if (value > 95) {
                    return "Must be at most 95";
                }

                break;
        }
    };

    this.renderHtml = function () {
        return '<div class="widget-content widget-propertytable"></div>';
    };

    return this;
};
