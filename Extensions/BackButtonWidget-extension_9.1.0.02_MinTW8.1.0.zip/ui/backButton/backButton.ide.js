﻿/*global Encoder,TW */

TW.IDE.Widgets.backButton = function () {
    "use strict";
    var roundedCorners = true; // not relevant to back button

    this.widgetIconUrl = function () {
        return  "../Common/extensions/BackButtonWidget-extension/ui/backButton/images/backButton.ide.png";
    };

    this.widgetProperties = function () {
        return {
            'name': 'Back Button',
            'description': 'Returns the user to the previous page',
            'category': ['Common'],
            'supportsTooltip': true,
            'properties': {
                'CustomClass': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.custom-class.description'),
                    'baseType': 'STRING',
                    'isLocalizable': false,
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'isVisible': false
                 },
                'Label': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.label.description'),
                    'defaultValue': '',
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'ContextId': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.context-id.description'),
                    'baseType': 'STRING',
                    "defaultValue": '',
                    'isBindingSource': true,
                    'isBindingTarget': true
                },
                'Width': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.width.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 32
                },
                'Height': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.height.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 32
                   // 'isEditable': false
                },
                'TabSequence': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.tab-sequence.description'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'RoundedCorners': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.rounded-corners.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                'Disabled': {
                    'description':     TW.IDE.I18NController.translate('tw.button-ide.properties.disabled.description'),
                    'baseType':        'BOOLEAN',
                    'defaultValue':    false,
                    'isBindingTarget': true
                },
                'Style': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'PTC.Factory.BackToOverviewBTN'
                },
                'HoverStyle': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.hover-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'PTC.SCA.SCO.NoStyle'
                },
                'ActiveStyle': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.active-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'PTC.SCA.SCO.NoStyle'
                },
                'FocusStyle': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.focus-style.description'),
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'PTC.SCA.SCO.NoStyle'
                },
                'DisabledStyle': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.disabled-style.description'),
                    'baseType':     'STYLEDEFINITION',
                    'defaultValue': 'PTC.SCA.SCO.Factory.BackToOverviewBTN_Disabled'
                },
                'IconAlignment': {
                    'description': TW.IDE.I18NController.translate('tw.button-ide.properties.icon-alignment.description'),
                    'baseType': 'STRING',
                    'defaultValue': 'left',
                    'selectOptions': [
                        { value: 'left', text: TW.IDE.I18NController.translate('tw.button-ide.properties.icon-alignment.select-options.left') },
                        { value: 'right', text: TW.IDE.I18NController.translate('tw.button-ide.properties.icon-alignment.select-options.right') }
                    ]
                }
            }
        };
    };

    this.widgetEvents = function () {
        return {
 		 'Clicked': {}
        };
    };

    this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Label' :
            case 'Style':
            case 'Width':
            case 'Height':
            case 'RoundedCorners':
            case 'HoverStyle':
            case 'IconAlignment':
                result = true;
                break;
            default:
                break;
        }
        return result;
    };


    this.renderHtml = function () {

        var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style', 'PTC.Factory.BackToOverviewBTN'));
        var formatResult2 = TW.getStyleFromStyleDefinition(this.getProperty('HoverStyle', 'DefaultButtonHoverStyle'));
        var formatResult3 = TW.getStyleFromStyleDefinition(this.getProperty('ActiveStyle', 'DefaultButtonActiveStyle'));
        var textSizeClass = 'textsize-normal';
        if (this.getProperty('Style') !== undefined) {
            textSizeClass = TW.getTextSizeClassName(formatResult.textSize);
        }

        var html = '';

        html +=
            '<div class="widget-content widget-button">'
                + '<div class="widget-button-overflow">'
                    + '<div class="widget-button-wrapper">'
                        + '<div class="widget-button-element">'
                            + '<div class="widget-button-content">'
                                + '<span class="widget-button-icon">'
                                    + ((formatResult.image !== undefined && formatResult.image.length > 0) ? '<img class="default" src="' + formatResult.image + '"/>' : '')
                                    + ((formatResult2.image !== undefined && formatResult2.image.length > 0) ? '<img class="hover" src="' + formatResult2.image + '"/>' : '')
                                    + ((formatResult3.image !== undefined && formatResult3.image.length > 0) ? '<img class="active" src="' + formatResult3.image + '"/>' : '')
                                + '</span>'
                                + '<span class="widget-button-text ' + textSizeClass + '" >' + (this.getProperty('Label') === undefined ? 'Button' : Encoder.htmlEncode(this.getProperty('Label'))) + '</span>'
                            + '</div>'
                        + '</div>'
                    + '</div>'
                + '</div>'
          + '</div>';
        return html;
    };

    this.afterRender = function () {
        var thisWidget = this;

        var buttonStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style'));
        var buttonHoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle'));
        var buttonActiveStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('ActiveStyle'));

        var buttonBackground = TW.getStyleCssGradientFromStyle(buttonStyle);
        var buttonText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonStyle);
        var buttonBorder = TW.getStyleCssBorderFromStyle(buttonStyle);
        var buttonHoverBG = TW.getStyleCssGradientFromStyle(buttonHoverStyle);
        var buttonHoverText = TW.getStyleCssTextualNoBackgroundFromStyle(buttonHoverStyle);
        var buttonHoverBorder = TW.getStyleCssBorderFromStyle(buttonHoverStyle);
        var cssButtonActiveBackground = TW.getStyleCssGradientFromStyle(buttonActiveStyle);
        var cssButtonActiveBorder = TW.getStyleCssBorderFromStyle(buttonActiveStyle);

        roundedCorners = this.getProperty('RoundedCorners');
        if (roundedCorners === undefined) {
            roundedCorners = true;
        }

        if (roundedCorners === true) {
            thisWidget.jqElement.addClass('roundedCorners');
        }

        thisWidget.jqElement.mousedown(function() {
            thisWidget.jqElement.addClass('active');
        }).mouseup(function(){
            thisWidget.jqElement.removeClass('active');
        });

        if (buttonStyle.image.length > 0) {
            thisWidget.jqElement.addClass('hasImage');
        }

        if (buttonHoverStyle.image.length === 0) {
            thisWidget.jqElement.addClass('singleImageOnly');
        }

        var buttonBorderWidth = TW.getStyleCssBorderWidthOnlyFromStyle(buttonStyle);
        var buttonHeight = this.getProperty('Height');
        var adjBtnHeight = (buttonHeight - (2 * buttonBorderWidth));
        var styleFirstRow = '#' + thisWidget.jqElementId + ' .widget-button-overflow { ' + buttonBackground + buttonBorder + ' height: ' + buttonHeight + 'px; } ';

        if (this.hasCustomClass) {
            thisWidget.jqElement.find('.widget-button-element').css('height','calc(100% - '+ (2 * buttonBorderWidth)+'px');
            styleFirstRow = '#' + thisWidget.jqElementId + ' .widget-button-overflow { ' + buttonBackground + buttonBorder + ' height: 100%; } ';
        } else {
           	thisWidget.jqElement.find('.widget-button-element').css('height',adjBtnHeight);
        }

        var resource = TW.IDE.getMashupResource();
        var widgetStyles =
            styleFirstRow +
            '#' + thisWidget.jqElementId + ' .widget-button-overflow:hover { ' + buttonHoverBG + buttonHoverBorder + ' } ' +
            '#' + thisWidget.jqElementId + ' .widget-button-overflow:hover .widget-button-text {'+ buttonHoverText + '} ' +
            '#' + thisWidget.jqElementId + '.active .widget-button-overflow {'+ cssButtonActiveBackground + cssButtonActiveBorder +'}' +
            '#' + thisWidget.jqElementId + ' .widget-button-text {'+ buttonText + '} ';
        resource.styles.append(widgetStyles);

        var iconAlignment = this.getProperty('IconAlignment');
        var iconElement = thisWidget.jqElement.find('.widget-button-icon');
        buttonText = thisWidget.jqElement.find('.widget-button-text');

        if (buttonText.html().length === 0) {
            thisWidget.jqElement.addClass('iconOnly'); // don't pad for text
        }
        else {
            if (iconAlignment === 'right') {
                $(iconElement).insertAfter(buttonText);
                thisWidget.jqElement.addClass('iconRight');
            }
        }
    };
};
