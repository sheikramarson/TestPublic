﻿(function() {

    TW.Runtime.Widgets.videoplayer = function() {
        var thisWidget = this,
            videoEl;

        this.renderHtml = function() {
            var html = '<div class="widget-content widget-videoplayer"><video></video></div>';
            return html;
        };

        this.afterRender = function() {
            videoEl = thisWidget.jqElement.find('video')[0];
            videoEl.controls = thisWidget.getProperty('ShowControls');
        };

        this.serviceInvoked = function(serviceName) {
            if (serviceName === 'Play') {
                videoEl.play();
            } else if (serviceName === 'Pause') {
                videoEl.pause();
            } else {
                TW.log.error('Unexpected serviceName invoked "' + serviceName + '" on the video player widget');
            }
        };

        this.updateProperty = function(updatePropertyInfo) {
            if (updatePropertyInfo.TargetProperty === 'VideoURL') {
                videoEl.src = updatePropertyInfo.SinglePropertyValue;
                thisWidget.setProperty('VideoURL', updatePropertyInfo.SinglePropertyValue);
            } else if (updatePropertyInfo.TargetProperty === 'ShowControls') {
                thisWidget.setProperty('ShowControls', updatePropertyInfo.SinglePropertyValue);
                videoEl.controls = thisWidget.getProperty('ShowControls');
            }
        };
    };
}());
